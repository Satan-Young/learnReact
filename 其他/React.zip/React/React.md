# React前端框架

**React** 是一个用于构建用户界面的 JavaScript 库，是一个数据驱动的MVVM模式的框架。

学习网站：https://zh-hans.reactjs.org/

![image-20220722170758047](image/image-20220722170758047.png)

# 第一章

学习目标：

+ React简介
+ hello world
+ JSX
+ 元素渲染
+ 生命周期
+ 组件
+ 事件

## 1 React简介

React 是一个声明式，高效且灵活的用于构建用户界面的 JavaScript 库。React起源于 Facebook 的内部项目，用来架设 Instagram 的网站，并于 2013 年 5 月开源。

React 主要用于构建 UI，很多人认为 React 是 MVC 中的 V（视图）。

React 拥有较高的性能，代码逻辑非常简单，越来越多的人已开始关注和使用它。

React 的生态体系比较庞大，它在web端，移动端，桌面端、服务器端，VR领域都有涉及。react可以说是目前为止最热⻔，生态最完善，应用范围最广的前端框架。react结合它的整个生态，它可以横跨web端，移动端，服务器端，乃至VR领域。可以毫不夸张地说，react已不单纯是一个框架，而是一个行业解决方案。

React特点:

- 声明式设计：React采用声明范式，可以轻松描述应用。

- 高效：React通过对DOM的模拟，最大限度地减少与DOM的交互。

- 灵活：React可以与已知的库或框架很好地配合。

- JSX：JSX 是JavaScript语法的扩展。React 开发不一定使用 JSX ，但我们建议使用它。

- 组件：通过 React构建组件，使得代码更加容易得到复用，能够很好的应用在大项目的开发

  中。

- 单向响应的数据流：React 实现了单向响应的数据流，从而减少了重复代码，这也是它为什

  么比传统数据绑定更简单。
  

## 2 hello world

我们先在html中引入react，来学习react的核心技术。

步骤 1： 添加一个 DOM 容器到 HTML

```html
<div id="app"></div>
```

步骤 2：添加 Script 标签

```html
<!-- 引入react -->
<script src="https://unpkg.com/react@17/umd/react.development.js" crossorigin></script>
<script src="https://unpkg.com/react-dom@17/umd/react-dom.development.js" crossorigin></script>

<!-- 引入babel -->
<script src="https://cdn.bootcss.com/babel-standalone/6.26.0/babel.min.js"></script>
```

步骤 3：编写react代码

```html
<script type="text/babel">
   console.log(ReactDOM.render);
   ReactDOM.render(<h1>hello world</h1>, document.getElementById('app')); 
</script>
```

完整代码：

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <script src="https://unpkg.com/react@17/umd/react.development.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@17/umd/react-dom.development.js" crossorigin></script>
  <script src="https://cdn.bootcss.com/babel-standalone/6.26.0/babel.min.js"></script>
</head>

<body>
  <div id="app"> </div>
  <script type="text/babel">
    console.log(ReactDOM.render);
    ReactDOM.render(<h1>hello world</h1>, document.getElementById('app')); 
  </script>
</body>

</html>
```

运行效果

<img src="image/image-20220626143308993.png" alt="image-20220626143308993" style="zoom:50%;" />

## 3 JSX

JSX，是一个 JavaScript 的语法扩展。建议在 React 中配合使用 JSX，JSX 可以很好地描述 UI 应该呈现出它应有交互的本质形式。JSX 可能会使人联想到模版语言，但它具有 JavaScript 的全部功能。

### 3.1 嵌入表达式

```jsx
const name = 'Josh Perez';
const element = <h1>Hello, {name}</h1>;
const obj = {name:"terry",age:12}
const element = <div>{JSON.stringify(obj)}</div>
```

![image-20220626144137535](image/image-20220626144137535.png)

![image-20220626144159540](image/image-20220626144159540.png)

### 3.2 动态属性

可以将一个动态值绑定在属性上

```jsx
let user = {avatarUrl:'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Ffile06.16sucai.com%2F2016%2F0815%2F5f6558119f85715076f40b919d2c9e52.jpg&refer=http%3A%2F%2Ffile06.16sucai.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1658817546&t=de41938b595863349b1450605a1476a7'};

const element=<img src={user.avatarUrl}></img>;
```

![image-20220626144111072](image/image-20220626144111072.png)

### 3.3 子元素

```jsx
const element = ( 
 <div>
  	<h1>Hello!</h1>
  	<h2>Good to see you here.</h2> 
 </div>
);
```

![image-20220626144045178](image/image-20220626144045178.png)

### 3.4 JSX表示对象

Babel 会把 JSX 转译成一个名为 React.createElement() 函数调用。 以下两个写法完全等价。

```jsx
const element = (
  <h1 className="greeting">
  	Hello, world! 
  </h1>
);
const element = React.createElement(
	'h1',
	{className: 'greeting'}, 
  'Hello, world!'
);
```

![image-20220626144316496](image/image-20220626144316496.png)

### 3.5 JSX内使用css

行内样式表

```jsx
<div style={{ border: '1px solid red' }}></div>
```

外部样式表
```jsx
// 在App.css文件中提供一个one类
import './App.css'
// jsx
<div className="one"></div>
```

## 4 元素渲染

### 4.1 react更新

React DOM 会将元素和它的子元素与它们之前的状态进行比较，并只会进行必要的更新来使 DOM 达到预期的状态。

```html
<div id="app"> </div>
<script type="text/babel">
  function tick() {
    const element = (
      <div>
        <h2>hello tick</h2>
        <div>{new Date().getTime()}</div>
      </div>
    );
    ReactDOM.render(element, document.getElementById('app'));
  }
  tick();
  setInterval(tick, 1000);
</script>
```

![image-20220626144756490](image/image-20220626144756490.png)

### 4.2 基本渲染

JSX变量渲染

```html
<!-- 获取msg变量进行渲染-->
<div>{msg}</div>
<!-- 函数组件获取父组件传递的数据进行渲染-->
<div>{props.msg}</div>
<!-- 类组件获取父组件传递的数据进行渲染-->
<div>{this.props.msg}</div>
<!-- 类组件获取当前组件内的state中的数据进行渲染，函数组件没有state-->
<div>{this.state.msg}</div>
```

### 4.3 条件渲染

```jsx
let flag = Math.random() > 0.5;
let element = flag ? <div>大</div> : <div>小</div>
ReactDOM.render(element, document.getElementById('app'));
```

![image-20220626145630124](image/image-20220626145630124.png)

![image-20220626145644666](image/image-20220626145644666.png)

### 4.4 列表渲染

```jsx
let list = [
  {
    "id": 36,
    "title": "【通知】教育部等11部门关于推进中小学生研学旅行的意见",
    "content": "<p>test</p>",
    "publishTime": 1590150600197,
    "authorId": null,
  },
  {
    "id": 57,
    "title": "法国夏令营开始报名了",
    "content": "<p>test</p>",
    "publishTime": 1598336993894,
    "authorId": null,
  },
  {
    "id": 66,
    "title": "【公告】山西省少先队员“红领巾研学行”正式启动",
    "content": "<p>test</p>",
    "publishTime": 1599751107354,
    "authorId": null,
  },
  {
    "id": 68,
    "title": "嘉峪关夏令营开始报名了",
    "content": "<p>嘉峪关夏令营开始报名了</p>",
    "publishTime": 1600000627631,
    "authorId": null,
}];
let element = list.map((item, index) => {
  return (
    <tr>
      <td>{index + 1}</td>
      <td>{item.title}</td>
      <td>{item.authorId}</td>
      <td>{item.publishTime}</td>
    </tr>
  )
})
ReactDOM.render(element, document.getElementById('app'));
```

![image-20220626145555136](image/image-20220626145555136.png)

## 5 生命周期

### 5.1 挂载阶段

从组件实例被创建到插入 DOM 中的阶段。

#### 1 constructor(props)

在 React 组件挂载之前，会调用它的构造函数。主要用于初始化state、为实例方法绑定 this。如果组件类继承自React.Component，在构造函数中应先调用super(props)，需要注意的是，不用在构造函数中使用this.setState()。还可以更改事件处理程序this的指向。

```js
constructor(props) {
  super(props);
  // Don't call this.setState() here!
  // Don't do this!
  // this.state = { color: props.color }; 
  this.state = { counter: 0 };
  this.handleClick = this.handleClick.bind(this);
}
```

#### 2 static getDerivedStateFromProps(props, state)

响应 Props 变化之后进行更新的方式。这个生命周期的功能实际上就是将传入的props映射到state上面。 该方法是一个静态方法，无法通过this直接访问。这个函数会在每次**re-rendering**之前被调用。

```js
static getDerivedStateFromProps(nextProps, prevState) {
  const { type } = nextProps;
  // 当传入的type发生变化的时候，更新state
  if (type !== prevState.type) {
    return {
      type,
    };
  }
  // 否则，对于state不进行任何操作
  return null;
}
```

#### 3 render()

该方法是 class 组件中唯一必须实现的方法。render函数应该是一个纯函数，意味着在不修改state值的时候该函数的返回值是一样的。

#### 4 componentDidMount()

会在组件挂载后(插入 DOM 树中)立即调用。依赖于 DOM 节点的初始化应该放在这里。如需通过网络请求获取数据，此处是实例化请求的好地方。这个方法是比较适合添加订阅的地方。如果添加了订阅，请不要忘记在 `componentWillUnmount()` 里取消订阅 。

### 5.2 更新阶段

当组件的 props 或 state 发生变化时会触发更新。组件就会进入到更新阶段

#### 1 static getDerivedStateFromProps(nextProps, nextState) 

#### 2 shouldComponentUpdate(nextProps, nextState)

根据该方法返回值判断 React 组件的输出是否受当前 state 或 props 更改的影响。默认行 为是 state 每次发生变化组件都会重新渲染。大部分情况下，你应该遵循默认行为。

#### 3 render()

#### 4 getSnapshotBeforeUpdate(prevProps, prevState)

#### 5 componentDidUpdate(prevProps, prevState, snapshot)

会在更新后会被立即调用，首次渲染不会执行此方法。当组件更新后，可以在此处对DOM 进行操作。如果你对更新前后的 props 进行了比较，也可以选择在此处进行网络请求。你也可以在 componentDidUpdate() 中直接调用 setState() ，但请注意它必须被 包裹在一个条件语句里，正如上述的例子那样进行处理，否则会导致死循环。它还会导致额 外的重新渲染，虽然用户不可⻅，但会影响组件性能。不要将 props “镜像”给 state，请考虑直接使用 props。

### 5.3 卸载阶段

当组件阶段当组件从 DOM 中移除时

#### componentWillUnmount() 



### 5.4 生命周期图

![image-20220626150255734](image/image-20220626150255734.png)

![image-20220626150323464.png](image/image-20220626150323464.png)



官网生命周期图谱：https://projects.wojtekmaj.pl/react-lifecycle-methods-diagram/

![image-20220626172757035](image/image-20220626172757035.png)

## 6 组件

**注意：组件的首字母一定要大写！**

### 6.1 函数组件

该函数是一个有效的 React 组件，因为它接收唯一带有数据的 “props”(代表属性)对象 与并返回一个 React 元素。这类组件被称为“函数组件”，因为它本质上就是 JavaScript 函数。 

相对比类组件，函数组件有以下特点：

+ 没有组件实例
+ 没有生命周期
+ 没有 state 和 setState，只能接收 props
+ 函数组件是一个纯函数，执行完即销毁，无法存储 state

```jsx
function Welcome(props) {
	return <h1>Hello, {props.name}</h1>;
}
ReactDOM.render(<Welcome name="tom" />, document.getElementById('app'));
```

![image-20220626151139795](image/image-20220626151139795.png)

### 6.2 类组件

通过类来定义一个组件。 类组件有以下特点：

+ 有组件实例
+ 有生命周期
+ 有 state 和 setState({})，`使用this.setState({name:'tom'})可以来修改state中的数据`

```jsx
class Welcome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: 'briup'
    };
  render() {
    return <h1>Hello, {this.props.name}, {this.state.name}</h1>;
  }
}
ReactDOM.render(<Welcome name="tom" />, document.getElementById('app'));
```

![image-20220626153636495](image/image-20220626153636495.png)

### 6.3 组件嵌套

在一个组件内使用另一个组件就形成组件嵌套，就有了父子组件的概念。

```jsx
// 表格组件
class MyTable extends React.Component{
  constructor(props) {
    super(props);
    this.state = {};
  }
  render(){
    return (
      <table>
        <tbody>
          <tr>
          	<MyTd />
          </tr>
        </tbody>
      </table>
    );
  }
}
// 表格的td组件
class MyTd extends React.Component{
  constructor(props) {
    super(props);
    this.state = {};
  }
  render(){
    return (
      <React.Fragment>   
        <td>1</td>
        <td>2</td>
        <td>3</td>
        <td>4</td>
      </React.Fragment>
    );
  }      
}
ReactDOM.render(<MyTable />,document.getElementById('app'));
```

> *React.Fragment*作用：可以将内部内容当做一个整体，而不产生其他标签。

### 6.4 父子组件通信

父与子组件测试

```jsx
const Parent = (props) => {
  let myHandler = (message) => {
    console.log('从子组件中接受的数据：', message);
  }
  return <Child name="我是父组件的数据" myA={myHandler}></Child>
}

const Child = ({ name, myA }) => {
  // 调用myA方法执行，来将子组件内的数据传递给父组件的函数
  myA('我是子组件的数据');
  return <div>
    父组件传递的数据：{name}
  </div>
}
ReactDOM.render(<Parent />,document.getElementById('app'));
```

效果

![image-20220712155252139](image/image-20220712155252139.png)

> 父给子：在父内使用子组件的时候，以属性的形式传递数据给子组件，子组件内使用props接收。
>
> 子给父：本质上是通过回调函数的方式来实现。在父内使用子组件的时候，给其传递函数，属性名称自定义。在子内部，通过props获取该属性，在子内部调用属性所对应的方法的执行，传递实参。

## 7 事件

### 7.1 事件处理程序与事件绑定

在类组件内使用类内的方法来声明事件处理程序。

```js
class MyCom extends React.Component {
  // 事件处理程序
  myHandler(event) {
    console.log('事件处理程序');
   	console.log(this);  //undefined，可将此函数换为箭头函数
  }
  render() {
   	// 事件绑定
    return <button onClick={this.myHandler}>按钮</button>
  }
}
ReactDOM.render(<MyCom />, document.getElementById('app'));
```

事件处理程序内的this指向undefined，如果想要指向该组件，有以下三个方案。

方案一：将事件处理程序声明为箭头函数

```js
myHandler = (event) => {
  console.log('事件处理程序');
  console.log(this);  //指向当前组件
}
```

方案二：在绑定的事件处理程序的时候使用箭头函数

```js
render() {
  return <button onClick={(e)=>{this.myHandler(e)}}>按钮</button>
}
```

方案三：需要在构造器中使用如下代码来修改函数内的this指向

```js
constructor(props) {
    super(props);
  	this.state = {};
    // 修改事件处理程序内部this指向
    this.myHandler = this.myHandler.bind(this);
 }
```

方案四：在绑定的事件处理程序的时候指定this指向

```js
render() {
  return <button onClick={this.myHandler.bind(this)}>按钮</button>
}
```

参考代码

```jsx
class MyCom extends React.Component {
  constructor(props) {
    super(props);
    // state状态
    this.state = {
      msg: 'hello',
      name: 'briup',
    };
    // 修改事件处理程序内部this指向
    this.myHandler = this.myHandler.bind(this);
  }
  myHandler(event) {
    console.log('事件处理程序');
    console.log(this);  // 这里this指向组件实例本身
    // 这里修改state中的数据
    this.setState({
      msg: "你好"
    })
  }
  render() {
    return <button onClick={this.myHandler}>{this.state.msg}, {this.state.name}</button>
  }
}
ReactDOM.render(<MyCom />, document.getElementById('app'));
```

![image-20220626154112257](image/image-20220626154112257.png)



### 7.2 事件传参

bind传参，最后一个参数是事件对象event。

```js
// bind绑定事件并传参
onClick = {this.handle.bind(this,1001,1002)}
// 事件处理程序接收参数
handle = (a,b,e)=>{
  this
  a 1001
  b 1002 
  e event
} 
handle(a,b,e){
  this
  a 1001
  b 1002 
  e event
} 
```

箭头函数传参，原则上没有固定顺序，建议与bind保持一致

```js
// bind绑定事件并传参
onClick={(e)=>{this.handle(1001,1002,e)}}
// 事件处理程序接收参数
handle = (a,b,e)=>{
  this
  a 1001
  b 1002 
  e event
} 
handle(a,b,e){
  this
  a 1001
  b 1002 
  e event
}
```

# 第二章

学习目标：

+ 表单
+ 脚手架
+ react-router

## 1 表单

### 1.1 受控组件

在 HTML 中，表单元素(如 `<input>` 、 `<textarea>` 和 `<select>` )通常自己维护 state，并根据用户输入进行更新。而在 React 中，可变状态(mutable state)通常保存在组件的 state 属性中，并且只能通过使用 `setState()` 来更新。我们可以把两者结合起来，使 React 的 state 成为“唯一数据源”。渲染表单的 React 组件还控制着用户输入过程中表单发生的操作。被 React 以这种方式控制取值的表单输入元素就叫做“受控组件”。

```jsx
class FormContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
        name: '',
        gender: '男',
        province: ''
      }
    }
    this.handleNameChange = this.handleNameChange.bind(this);
    this.handleGenderChange = this.handleGenderChange.bind(this);
    this.handleProvinceChange = this.handleProvinceChange.bind(this);
  }
  handleNameChange(event) {
    this.setState({
      form: {
        ...this.state.form, name: event.target.value
      }
    })
  }
  handleGenderChange(event) {
    this.setState({
      form: {
        ...this.state.form,
        gender: event.target.value
      }
    })
  }
  handleProvinceChange(event) {
    this.setState({
      form: {
        ...this.state.form, province: event.target.value
      }
    })
  }
  render() {
    let { form } = this.state;
    return (
      <div>
        {JSON.stringify(form)}
        <form action="">
          <div>
            姓名：
            <label htmlFor="">
              <input type="text" value={form.name} onChange={this.handleNameChange} />
            </label>
          </div>
          <div>
            性别：
            <label htmlFor="">
              <input type="radio" name="gender" checked={form.gender == '男'} value="男" onChange={this.handleGenderChange} />
              男
            </label>
            <label htmlFor="">
              <input type="radio" name="gender" checked={form.gender == '女'} value="女" onChange={this.handleGenderChange} />
              女
            </label>
          </div>
          <div>
            求职地：
            <select onChange={this.handleProvinceChange}>
              <option value="上海">上海</option>
              <option value="苏州">苏州</option>
              <option value="无锡">无锡</option>
            </select>
          </div>
        </form>
      </div>
    )
  }
}
ReactDOM.render(<FormContainer />, document.getElementById('app'));
```

![image-20220626152554759](image/image-20220626152554759.png)

### 1.2 非受控组件

要编写一个非受控组件，而不是为每个状态更新都编写数据处理函数，你可以使用 ref 来从 DOM 节点中获取表单数据。在非受控组件中，你经常希望 React 能赋予组件一个初始值， 但是不去控制后续的更新。 在这种情况下，你可以指定一个 defaultValue 属性，而不是value。

```jsx
class FormContainer extends React.Component {
  constructor(props) {
    super(props); this.state = {
      form: {
        name: '',
        gender: '男',
        province: ''
      }
    }
    this.input_name = React.createRef();
    this.input_gender = React.createRef();
    this.select_province = React.createRef();
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(event) {
    console.log(this.input_name.current.value);
    let form = {
      name: this.input_name.current.value,
      gender: this.input_gender.current.value,
      province: this.select_province.current.value,
    }
    event.preventDefault();
  }
  render() {
    return (
      <div>
        <form action="" onSubmit={this.handleSubmit}>
          <div>
            <label htmlFor="">
              姓名：
              <input type="text" ref={this.input_name} defaultValue="tom" />
            </label>
          </div>
          <div>
            性别：
            <label htmlFor="">
              <input type="radio" ref={this.input_gender} name="gender" defaultChecked value="男" />
              男
            </label>
            <label htmlFor="">
              <input type="radio" ref={this.input_gender} name="gender" value="女" />
              女
            </label>
          </div>
          <div>
            求职地：
            <select ref={this.select_province} defaultValue="苏州">
              <option value="上海">上海</option>
              <option value="苏州">苏州</option>
              <option value="无锡">无锡</option>
            </select>
          </div>
          <div>
            <input type="submit" value="提交" />
          </div>
        </form>
      </div>)
  }
}
ReactDOM.render(<FormContainer />, document.getElementById('app')); 
```



## 2 脚手架

学习网站：https://create-react-app.dev/docs/getting-started/

```shell
# 如果之前安装过create-react-app，要先进行卸载 
$ npm uninstall -g create-react-app
# 创建好项目后，依赖自动下载好了，不用再下载项目的依赖了
$ npx create-react-app my-app
$ cd my-app
$ npm start
# 启动之后，在http://localhost:3000端口上访问react脚手架的项目
```

对于要构建的项目，**这些文件必须以准确的文件名存在**：

- `public/index.html`是页面模板；
- `src/index.js`是 JavaScript 入口点。

项目目录如下：

你可以在里面创建子目录`src`。为了更快地重建，webpack 只处理src内部的文件。你需要**将任何 JS 和 CSS 文件放入`src`**其中，否则 webpack 将看不到它们。

```shell
├── README.md
├── package.json
├── public
│   ├── favicon.ico
│   └── index.html
├── src
│   ├── App.css
│   ├── App.js
│   ├── App.test.js
│   ├── index.css
│   ├── index.js
│   └── logo.svg
└── yarn.lock
```

![image-20220626161307257](image/image-20220626161307257.png)

可以在src下创建pages文件夹来放置页面，创建components 放置公用组件，创建utils文件夹放置工具文件。

项目访问如下：

![image-20220626155756258](image/image-20220626155756258.png)

## 3 react-router

React Router 是一个基于 [React](http://facebook.github.io/react/)  之上的强大路由库，它可以让你向应用中快速地添加视图和数据流，同时保持页面与 URL 间的同步。

目前文档对应react-router版本：V6.X，V6.X 版本相对与V5.X做出很大改变。

react-router的6.0版本改变：

1. 路由注册将`<Switch />`改成了`<Routes />`

2. 路由引入将component改成了element

3. 新增多个hook新增组件....

路由相关插件：

> react-router插件是路由库的核心；
>
> react-router-dom插件是web程序的路由库，在react-router基础上添加了dom操作；
>
> react-router-native是app程序的路由库，在react-router基础上添加了本地操作；

在此之前建议配合react脚手架一起使用。

学习网站：https://reactrouter.com/docs/en/v6/getting-started/overview、https://reactrouter.com/core/guides/quick-start

### 3.1 安装

```shell
$ npm install react-router-dom@6 --save
# 安装react-router-dom的产品依赖，会帮助我们将路由操作dom的依赖安装完成
```

### 3.2 常用组件

注意：在跳转路由时，如果路径是`/`开头的则是绝对路由，否则为**相对路由**，即相对于“当前URL”进行改变。

#### BrowserRouter组件

路由的根组件。

#### Link组件

其中Link标签对A标签进行了封装，可以进行路由的跳转；`Link组件`只能在Router内部使用，因此使用到`Link组件`的组件一定要放在顶层的Router之内。

#### NavLink组件

- `NavLink组件`和`Link组件`的功能是一致的，区别在于可以判断其`to属性`是否是当前匹配到的路由
- `NavLink组件`的`style`或`className`可以接收一个函数，函数接收一个`isActive参数`，可根据该参数调整样式

这里的Link或NavLink类似于Vue中的Router-link。

#### Routes组件

Routes功能上类似于Vue中的Router-view。将来匹配到的路由组件将会被加载到Routes所在的位置。

Routes组件内部存放Route组件。

#### Route组件

Route组件则是用来匹配路由对应的页面组件，在v5之前在使用Switch包裹的Route标签，在V6.X版本以后变成了Routes，并且Route标签中的component属性变成了element属性。

```jsx
<Route path="/about" element={<About></About>}></Route>
```

#### 案例

在App.js中只需要从react-router-dom引入以下组件：

```js
import {BrowserRouter,Route,Routes,Link} from 'react-router-dom';
```

使用路由组件：

```jsx
<BrowserRouter>
	<Link to="/home">home</Link>
  <br />
  <Link to="/about">about</Link>
  <hr />
  hello
  <div>
    <Routes>
      <Route path="/" element={<Home></Home>}></Route>
      <Route path="/about" element={<About></About>}></Route>
      <Route path="/home" element={<Home></Home>}></Route>
    </Routes>
  </div>
</BrowserRouter>
```

### 3.3 小试牛刀

先提供两个组件

Home组件

```jsx
//src/pages/Home.jsx
import React from 'react'
export default class Home extends React.Component {
  render() {
    return <h1>Home页面</h1>
  }
}
```

About组件

```jsx
//src/pages/About.jsx
import React from 'react'
export default class About extends React.Component {
  render() {
    return <h1>About页面</h1>
  }
}
```

使用路由

```jsx
//src/app.js
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import Home from './pages/Home'
import About from './pages/About';
// import './App.css'
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Link to="/home">home</Link>
        <br />
        <Link to="/about">about</Link>
        <hr />
        hello
        <div>
          <Routes>
            <Route path="/" element={<Home></Home>}></Route>
            <Route path="/about" element={<About></About>}></Route>
            <Route path="/home" element={<Home></Home>}></Route>
          </Routes>
        </div>
      </BrowserRouter >
    </div >
  );
}
export default App;
```

最终可以实现路由

![image-20220626165325180](image/image-20220626165325180.png)

![image-20220626165242063](image/image-20220626165242063.png)

### 3.4 其他功能

#### 路由种类

react提供了两种路由器，Browser、Hash，他们主要区别在于存储URL的⽅式以及与后端交互⽅式。

`<BrowserRouter>` 类似于history模式，url格式看上去⾮常和谐，但是服务器需要进⾏配置， 否则会与后端进⾏交互。

`<HashRouter>` 路径会保存在url后，通过#分割，这种⽅式不会与后端进⾏交互。

可以将上方案例中的BrowserRouter组件更改为HashRouter组件对比查看效果。

BrowserRouter组件效果

![image-20220626232021715](image/image-20220626232021715.png)

HashRouter组件效果

![image-20220626231913696](image/image-20220626231913696.png)

#### 重定向

React-route6.0版本已经移除了Redirect组件，实现重定向可以使用通配符配合Navigate组件的方式实现。

```jsx
import { Navigate, Route } from "react-router-dom";

// ...
// 将/a路由重定向到/home路由
<Route path='/a' element={<Navigate to='/home'></Navigate>}></Route>

// 以下代码可实现其他未定义的路由路径重定向到/home路由
<Route path='*' element={<Navigate to='/home'></Navigate>}></Route>
```

#### 路由高亮

路由高亮效果，activeClassName在6版本已经不再使用，如果需要实现高亮效果，将className写成函数的形式，函数接收一个参数，参数为一个对象名有isActive属性，该属性值为true，表示该路由被激活。

在App.css中编写两个类，分别代表激活的样式active-pages和未激活的样式pages

```css
/* App.css */
a {
  text-decoration: none;
}

.active-pages {
  background-color: teal;
  color: white;
}

.pages {
  background-color: white;
  color: teal;
}
```

在NavLink组价上使用className来进行高亮设置。

```jsx
import { NavLink } from "react-router-dom";
import './App.css'

// ....
<NavLink className={(a)=>{return a.isActive ? 'acitve-pages': 'pages'}}  to="/home">Home</NavLink>
<br>
<NavLink className={(a)=>{return a.isActive ? 'acitve-pages': 'pages'}} to="/about">关于</NavLink>
// ....
```

> `<Link>` 最基本的路由 
>
> `<NavLink>` 带有激活状态的路由

<img src="image/image-20220627111334427.png" alt="image-20220627111334427" style="zoom:33%;" />

### 3.5 嵌套路由

#### 路由表文件

react-route6支持路由表配置了，新建一个文件夹routes，在新建一个路由表文件index.js，配置路由规则。

```jsx
// routes/index.js
import Home from '../pages/Home'
import About from '../pages/About';
import PathQuery from '../pages/PathQuery';
import RouteParams from '../pages/RouteParams';
import { Navigate } from 'react-router-dom';
let routes = [
  {
    path: '/test',
    // 重定向
    element: <Navigate to='/home' />
  },
  {
    path: '/home',
    element: <Home />
  },
  {
    path: '/about',
    element: <About />
  },
  // 对其他路由的处理
  {
    path: '*',
    element: <Navigate to='/home' />
  },
]
export default routes
```

**值得注意的是：路由表的使用方式的必须是Hooks的方式，即组件必须是函数组件，类组件无法实现。**

使用路由表文件有如下三步骤：

1. 导入路由表文件
2. 注册路由表
3. 使用路由表

```jsx
// App.js
import { BrowserRouter, NavLink, Navigate, Route, Routes, useRoutes } from "react-router-dom";
// 1.导入路由表
import indexRoutes from './routes'
import './App.css'
// 2.注册路由表进行使用
function RouteElement() {
  return useRoutes(indexRoutes)
}

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/test">redirect to home</NavLink>
        <br />
        <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/home">home</NavLink>
        <br />
        <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/about">about</NavLink>
        <br />
        {/* 3.使用路由表 */}
        <RouteElement></RouteElement>
         {/* 以下内容就可以不用了 */}
        {/*  <Routes>
            <Route path="/" element={<Home></Home>}></Route>
            <Route path="/about" element={<About></About>}></Route>
            <Route path="/home" element={<Home></Home>}></Route>
            <Route path='*' element={<Navigate to='/home'></Navigate>}></Route>
          </Routes> */}
      </BrowserRouter>
    </div >
  );
}
export default App;
```

![image-20220705171626975](image/image-20220705171626975.png)

#### 嵌套路由

```jsx
// routes/index.js
// ... 此处导入路由组件，User1和User2内部的内容简单提供即可。重点注意下方User组件内的内容
export default [
    {
        path: '/home',
        element: <Home />
    },
  	// ...
    {
        path: '/user',
        element: <User />,
        children: [
            {
                path: 'user1',
                element: <User1 />
            },
            {
                path: 'user2',
                element: <User2 />
            },
        ]
    }
]
```

使用路由出口组件Outlet（类似vue的routerView）

```jsx
// pages/User.js
import { NavLink, Outlet } from "react-router-dom";
export default function User() {
  return <div>
    User页面
    <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="user1">用户一</NavLink>
    <br />
    <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="user2">用户二</NavLink>
    <br />
    {/* 使用Outlet来加载路由子组件 */}
    <Outlet></Outlet>
  </div>
}
```

![image-20220705171801991](image/image-20220705171801991.png)

### 3.6 路由传参

组件路由传参和5版本的一样，只是由于是函数式组件接收参数需要借助hooks来实现。

#### 查询字符串参数

- 查询参数不需要在路由中定义
- 使用`useSearchParams` hook来访问查询参数。其用法和useState类似，会返回当前对象和更改它的方法
- 更改searchParams时，必须传入所有的查询参数，否则会覆盖已有参数。

路由跳转

```jsx
<NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/pathQuery?name=zhangsan&age=12">pathQuery</NavLink>
```

路由规则声明

```js
// routes/index.js
import PathQuery from '../pages/PathQuery';
// ....
{
  path: '/pathQuery',
  element: <PathQuery />
},
// ....
```

路由组件内使用useSearchParams来接受参数

```jsx
import { useSearchParams } from 'react-router-dom';

// 当前路径为 /pathQuery?name=zhagnsan&age=12
export default function PathQuery() {
  const [searchParams, setSearchParams] = useSearchParams();
  /*setSearchParams({
    name: 'pathQuery'
  }) */
  // /pathQuery?name=pathQuery
  return (
    <div>路径查询字符串参数{searchParams.get('name')}</div>
  )
}
```

![image-20220705171215340](image/image-20220705171215340.png)

#### 动态路由参数

- 在路由的`path属性`中定义路径参数
- 在组件内通过`useParams` hook访问路径参数

路由跳转

```jsx
<NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/routeParams/1">routeParams</NavLink>
```

动态路由声明

```jsx
// routes/index.js
import RouteParams from '../pages/RouteParams';
// ....
{
  path: '/routeParams/:id',
  element: <RouteParams />
},
// ....
```

路由组件中接受参数

```jsx
import { useParams } from 'react-router-dom'
export default function RouteParams() {
  let params = useParams();
  return (
    <div>
      动态路由参数：{params.id}
    </div>
  );
}
```

![image-20220705171401724](image/image-20220705171401724.png)

#### 编程式路由导航

使用useNavigate(path,[obj])来进行编程式路由导航。

参数说明

+ path：路由路径 

+ obj：配置对象（携带参数）{state:{}}

##### 路由跳转

```jsx
// pages/TestApi.js
import { useNavigate } from "react-router-dom"
export default function TestApi() {
  const navigate = useNavigate();
  return <button onClick={
    () => {
      navigate('/home', {
        state: { id: 1, name: 'tom' }
      })
    }
  }>跳转到Home页面</button>
}
```

将TestApi当做路由组件来使用

```jsx
//routes/index.js
// import TestApi from '../pages/TestApi';
// ...
  {
    path: '/testApi',
    element: <TestApi />
  },
  {
    path: '/home',
    element: <Home />
  },
  {
    path: '/about',
    element: <About />
  },
// ...

```

在App.js中编写路由入口NavLink

```jsx
// app.js
// ...
<BrowserRouter>
  <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/home">home</NavLink>
  <br />
  <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/about">about</NavLink>
  <br />
  <NavLink className={(a) => { return a.isActive ? 'active-pages' : 'pages' }} to="/testApi">testApi</NavLink>
  <br />
  <RouteElement></RouteElement>
</BrowserRouter>
```

效果

![image-20220707095157984](image/image-20220707095157984.png)

##### 携带参数

在进行编程式导航的时候进行参数的携带

```js
navigate('/home', {
  // 此处必须为state，不能为其他属性
  state: { id: 1, name: 'tom' }
})
```

##### 参数获取

获取编程式导航携带的参数，使用state携带的参数可以在路由组件页面使用location获取

在Home.js中通过如下代码来获取编程式导航携带的参数

```js
import { useLocation } from 'react-router-dom'
export default function Home(props) {
  const location = useLocation()
  console.log(location.state);
  return <h1>Home页面{JSON.stringify(location)}</h1>
}
// 通过location.state就可以获取到参数
```

结果：

![image-20220707100253930](image/image-20220707100253930.png)

##### 前进后退

使用useNavigate()实现路由的前进和后退

```js
import { useNavigate } from 'react-router-dom'
// ...
// 在某个事件处理程序中
const navigate =useNavigate();
navigate(1);  //前进一个路由
navigate(-1);  //后退一个路由
```

修改TestApi.js中的内容，就可以实现前进和后退的效果

```jsx
export default function TestApi() {
  const navigate = useNavigate();
  return <div>
    <button onClick={
      () => {
        navigate(1)
      }
    }>前进</button>
    <button onClick={
      () => {
        navigate(1)
      }
    }>后退</button>
  </div>
}
```

# 第三章

学习目标：

+ Refs 
+ 高阶组件
+ Hook

## 1 Refs

Refs 提供了一种方式，允许我们访问 DOM 节点或在 render 方法中创建的 React 元素。 官方建议请勿过渡使用Refs【能不用就别用】。

下面是几个适合使用 refs 的情况：

- 管理焦点，文本选择或媒体播放。
- 触发强制动画。
- 集成第三方 DOM 库。

为元素上的ref属性可以绑定一个对象，也可以绑定一个回调函数。当ref属性值为对象的时候，ref会将当前dom赋值给这个对象的current属性；当ref属性会一个函数的时候，ref会将当前dom作为参数传递给这个回调函数。

ref 的值根据节点的类型而有所不同：

- 当 `ref` 属性用于 HTML 元素时，构造函数中使用 `React.createRef()` 创建的 `ref` 接收底层 DOM 元素作为其 `current` 属性。
- 当 `ref` 属性用于自定义 class 组件时，`ref` 对象接收组件的挂载实例作为其 `current` 属性。
- **你不能在函数组件上使用 `ref` 属性**，因为他们没有实例。

实际应用：

1. 给标签上设置ref="mydom"，通过`this.refs.mydom`来访问该DOM元素。
2. 给组件上设置ref="mycom"，通过`this.refs.mycom`可以获取到组件对象。
3. 新写法：`myRef = React.createRef()`，给标签上使用`<div ref={this.myRef}></div>`，通过`this.myRef.current`来访问该DOM元素。

### 1.1 创建 Refs

Refs 是使用 `React.createRef()` 创建的，并通过 `ref` 属性附加到 React 元素。在构造组件时，通常将 Refs 分配给实例属性，以便可以在整个组件中引用它们。

```jsx
class MyComponent extends React.Component {
  constructor(props) {
    super(props);
    this.myRef = React.createRef();
  }
  render() {
    return <div ref={this.myRef} />;
  }
}
```

### 1.2 访问 Refs

当 ref 被传递给 `render` 中的元素时，对该节点的引用可以在 ref 的 `current` 属性中被访问。

```js
const node = this.myRef.current;
```

### 1.3 示例

```jsx
//pages/Refs.js
import React from 'react'
export default class ComponentA extends React.Component {
  constructor(props) {
    super(props);
    // this.containerA = {current:null}
    this.containerA = React.createRef(); // {current:null} 
    this.containerB = null;
  }
  componentDidMount() {
    console.log(this.containerA.current);
    console.log(this.containerB);
  }
  render() {
    return (
      <div>
        <h2>Component A</h2>
        <div ref={this.containerA}>hello component</div>
        <div ref={(e) => {
          // e就是当前dom对象
          this.containerB = e;
        }}>hello component</div>
      </div>)
  }
}
```

在App.js中引入并使用该组件

```jsx
// App.js
import Refs from './pages/Refs'
// ....
export default function App() {
  return <div>
    <Refs></Refs>
  </div> 
}
// ....
```

![image-20220705174650697](image/image-20220705174650697.png)



此处发现componentDidMount内部代码执行了多次，如果不想执行多次，则在src/index.js中注释React.StrictMode代码：

```js
// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
  <App />
  // </React.StrictMode>
);

reportWebVitals();
```

结果：

![image-20220706173343010](image/image-20220706173343010.png)

### 1.4 为 DOM 元素添加 ref

React 会在组件挂载时给 `current` 属性传入 DOM 元素，并在组件卸载时传入 `null` 值。`ref` 会在 `componentDidMount` 或 `componentDidUpdate` 生命周期钩子触发前更新。

以下代码使用 `ref` 去存储 DOM 节点的引用：

```jsx
// pages/CustomTextInput.js
import React from 'react'
export default class CustomTextInput extends React.Component {
  constructor(props) {
    super(props);
    // 创建一个 ref 来存储 textInput 的 DOM 元素
    this.textInput = React.createRef();
  }

  focusTextInput= () => {
    // 直接使用原生 API 使 text 输入框获得焦点
    // 注意：我们通过 "current" 来访问 DOM 节点
    this.textInput.current.focus();
  }

  render() {
    // 告诉 React 我们想把 <input> ref 关联到
    // 构造器里创建的 `textInput` 上
    return (
      <div>
        <input
          type="text"
          ref={this.textInput} />
        <input
          type="button"
          value="Focus the text input"
          onClick={this.focusTextInput}
        />
      </div>
    );
  }
}
```

在App.js中引入并使用该组件

```jsx
// App.js
import CustomTextInput from './pages/CustomTextInput'
// ....
export default function App() {
  return <div>
    <CustomTextInput></CustomTextInput>
  </div> 
}
// ....
```

结果：点击按钮的时候会有输入框聚焦的效果

![image-20220705180457056](image/image-20220705180457056.png)

### 1.5 为 class 组件添加 Ref 

如果我们想包装上面的 `CustomTextInput`，来模拟它挂载之后立即被点击的操作，我们可以使用 ref 来获取这个自定义的 input 组件并手动调用它的 `focusTextInput` 方法：

```js
// pages/AutoFocusTextInput.js
import React from 'react'
import CustomTextInput from './CustomTextInput'
export default class AutoFocusTextInput extends React.Component {
  constructor(props) {
    super(props);
    this.textInput = React.createRef();
  }

  componentDidMount() {
    // 调用子组件内部的方法
    this.textInput.current.focusTextInput();
  }

  render() {
    return (
      <CustomTextInput ref={this.textInput} />);
  }
}
```

在App.js中引入并使用该组件

```jsx
// App.js
import AutoFocusTextInput from './pages/AutoFocusTextInput'
// ....
export default function App() {
  return <div>
    <AutoFocusTextInput></AutoFocusTextInput>
  </div> 
}
// ....
```

结果：页面一打开就聚焦在输入框

![image-20220705181103187](image/image-20220705181103187.png)

> 请注意，这仅在 `CustomTextInput` 声明为 class 时才有效



### 1.6 Refs 与函数组件 

默认情况下，**你不能在函数组件上使用 `ref` 属性**，因为它们没有实例。

可通过React.forwardRef或者useRef(Hook)来解决此问题。

```jsx
// pages/Parent.js
import React from "react";

function MyFunctionComponent(props, ref) {
  return <input ref={ref} />;
}
// 如果不想报错，编写如下代码
// MyFunctionComponent = React.forwardRef(MyFunctionComponent)
export default class Parent extends React.Component {
  constructor(props) {
    super(props);
    this.textInput = React.createRef();
  }
  componentDidMount() {
    console.log(this.textInput);
  }
  render() {
    // This will *not* work!
    return (
      <MyFunctionComponent ref={this.textInput} />);
  }
}
```

在App.js中引入并使用该组件

```jsx
// App.js
import Parent from './pages/Parent'
// ....
export default function App() {
  return <div>
    <Parent></Parent>
  </div> 
}
// ....
```

运行结果：

![image-20220706172815551](image/image-20220706172815551.png)

如果要在函数组件中使用 `ref`，你可以使用 [`forwardRef`](https://react.docschina.org/docs/forwarding-refs.html)（可与 [`useImperativeHandle`](https://react.docschina.org/docs/hooks-reference.html#useimperativehandle) 结合使用），或者可以将该组件转化为 class 组件。forwardRef的使用参见上方代码中注释的内容。

```js
// 如果想不报错，需要使用forwardRef方法
MyFunctionComponent = React.forwardRef(MyFunctionComponent)
```

结果：

![image-20220706172851193](image/image-20220706172851193.png)

不管怎样，你可以**在函数组件内部使用 `ref` 属性**，只要它指向一个 DOM 元素或 class 组件：

```jsx
function CustomTextInput(props) {
  // 这里必须声明 textInput，这样 ref 才可以引用它  
  const textInput = useRef(null);
  function handleClick() {
    textInput.current.focus();  
  }

  return (
    <div>
      <input
        type="text"
        ref={textInput} />      
      <input
        type="button"
        value="Focus the text input"
        onClick={handleClick}
      />
    </div>
  );
}
```

### 1.7 Refs转发

将 DOM Refs 暴露给父组件，在极少数情况下，你可能希望在父组件中引用子节点的 DOM 节点。通常不建议这样做，因为它会打破组件的封装，但它偶尔可用于触发焦点或测量子 DOM 节点的大小或位置。

虽然你可以向子组件添加 ref，但这不是一个理想的解决方案，因为你只能获取组件实例而不是 DOM 节点。并且，它还在函数组件上无效。

如果你使用 16.3 或更高版本的 React, 这种情况下我们推荐使用 [ref 转发](https://react.docschina.org/docs/forwarding-refs.html)。

可以通过React.forwardRef这个函数来实现，该函数接收一个函数组件作为参数。与其他函数组件不同，该函数组件可以接收2个参数props、ref。这个ref用来将子组件中的dom传递给父组件。

**Ref 转发使组件可以像暴露自己的 ref 一样暴露子组件的 ref**。

```jsx
// pages/FancyButton.js  子组件
import React from 'react'
function FancyButton(props, ref) {
  return <button ref={ref} className="FancyButton">
    {props.children}
  </button>
}
export default React.forwardRef(FancyButton);
```

父组件内使用该组件

```jsx
// pages/ButtonFowardRef.js  父组件内使用FancyButton子组件
import React from 'react'
import FancyButton from './FancyButton';
export default class ButtonFowardRef extends React.Component {
  constructor(props) {
    super(props);
    // 你可以直接获取 DOM button 的 ref：
    this.pRef = React.createRef();
  }
  componentDidMount() {
    console.log(this.pRef.current);
  }
  render() {
    return <FancyButton ref={this.pRef}>我是一个按钮</FancyButton>
  }
}
```

在App.js中引入并使用该父组件

```jsx
// App.js
import ButtonFowardRef from './pages/ButtonFowardRef'
// ....
export default function App() {
  return <div>
    <ButtonFowardRef></ButtonFowardRef>
  </div> 
}
// ....
```

结果：

![image-20220706172010041](image/image-20220706172010041.png)

这样，使用 `FancyButton` 的组件可以获取底层 DOM 节点 `button` 的 ref ，并在必要时访问，就像其直接使用 DOM `button` 一样。

以下是对上述示例发生情况的逐步解释：

1. 我们通过调用 `React.createRef` 创建了一个 React ref 并将其赋值给 `pRef` 变量。
2. 我们通过指定 `pRef` 为 JSX 属性，将其向下传递给 `<FancyButton ref={this.pRef}>`。
3. React 传递 `ref` 给 `forwardRef` 内函数 `(props, ref) => ...`，作为其第二个参数。
4. 我们向下转发该 `ref` 参数到 `<button ref={ref}>`，将其指定为 JSX 属性。
5. 当 ref 挂载完成，`pRef.current` 将指向 `<button>` DOM 节点。

> 注意
>
> 第二个参数 `ref` 只在使用 `React.forwardRef` 定义组件时存在。常规函数和 class 组件不接收 `ref` 参数，且 props 中也不存在 `ref`。
>
> Ref 转发不仅限于 DOM 组件，你也可以转发 refs 到 class 组件实例中。
>
> **当你开始在组件库中使用 `forwardRef` 时，你应当将其视为一个破坏性更改，并发布库的一个新的主版本。** 这是因为你的库可能会有明显不同的行为（例如 refs 被分配给了谁，以及导出了什么类型），并且这样可能会导致依赖旧行为的应用和其他库崩溃。
>
> 出于同样的原因，当 `React.forwardRef` 存在时有条件地使用它也是不推荐的：它改变了你的库的行为，并在升级 React 自身时破坏用户的应用。

## 2 高阶组件

高阶组件（HOC）是 React 中用于复用组件逻辑的一种高级技巧。HOC 自身不是 React API 的一部分，它是一种基于 React 的组合特性而形成的设计模式。

HOC(High Order Component) 是 react 中对组件逻辑复用部分进行抽离的高级技术，它只是一种设计模式，类似于装饰器模式。 

具体而言，HOC就是一个函数，且该函数接受一个组件作为参数，并返回一个新组件。 从结果论来说，HOC相当于 Vue 中的 mixins(混合)。

```jsx
const EnhancedComponent = higherOrderComponent(WrappedComponent);
```

组件是将 props 转换为 UI，而高阶组件是将组件转换为另一个组件。

HOC 在 React 的第三方库中很常见，例如 Redux 的 [`connect`](https://github.com/reduxjs/react-redux/blob/master/docs/api/connect.md#connect) 和 Relay 的 [`createFragmentContainer`](http://facebook.github.io/relay/docs/en/fragment-container.html)。

### 2.1 实现机制

#### props代理 

将公共代码通过props进行注入，在utils中编写HOCs.js文件，内容如下

```js
// utils/HOCs.js
// 给props中混入数据
import React from "react";
export function ppHOC(WrappedComponent) {
  class PP extends React.Component {
    render() {
      let props = {
        ...this.props,
        message: "add props"
      };
    return <WrappedComponent {...props} />;
  }
};
PP.staticMethod = WrappedComponent.staticMethod; // 静态方法
return PP;
```

在pages中编写TestProps.js文件

```jsx
import React from "react";
import { ppHOC } from "../../utils/HOCs";
class TestProps extends React.Component {
  static staticMethod = () => {
    console.log(this);
  }
  render() {
    return <div>
      {JSON.stringify(this.props)}
    </div>
  }
}
export default ppHOC(TestProps)
```

在App.js中引入并使用该TestProps组件

```jsx
// App.js
import TestProps from './pages/TestProps'
// ....
export default function App() {
  return <div>
    <TestProps></TestProps>
  </div> 
}
// ....
```

结果如下，此处可以发现已经在props中混入了数据

![image-20220707104136571](image/image-20220707104136571.png)





#### 反向继承

反向继承的方式，除了静态方法之外的生命周期，state，props，render 都可以在 HOC 中得到

```js
// utils/HOCs.js文件中添加如下代码
export function stateHOC(WrappedComponent) {
  class PP extends WrappedComponent {
    render() {
      console.log(this.state, "state");
      return super.render();
    }
  };
  PP.staticMethod = WrappedComponent.staticMethod; // 静态方法 
  return PP;
}
```

在pages中编写TestState.js文件

```jsx
// pages/TestState.js
import React from "react";
import { stateHOC } from "../../utils/HOCs";
class TestState extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      msg: '我是state中的数据'
    };
  }
  static staticMethod = () => {
    console.log(this);
  }
  render() {
    return <div>
      {JSON.stringify(this.props)}
    </div>
  }
}
export default stateHOC(TestState)
```

在App.js中引入并使用该TestState组件

```jsx
// App.js
import TestState from './pages/TestState'
// ....
export default function App() {
  return <div>
    <TestState></TestState>
  </div> 
}
// ....
```

结果如下，此处可以发现可以在高阶函数内获取到state和render

![image-20220707104037648](image/image-20220707104037648.png)



### 2.2 注意

- 不要在 render 方法中使用 HOC
- 务必复制静态方法
- Refs 不会被传递 ，可以通过 React.forwardRef 来进行传递

## 3 Hook

Hook 是 React 16.8 的新增特性。它可以让你在不编写 class 的情况下使用 state 以及其他的 React 特性。Hook 是一些可以让你在函数组件里“钩入” React state 及生命周期等特性的函数。Hook 不能在 class 组件中使用 —— 这使得你不使用 class 也能使用 React。可以在新组件中慢慢使用Hook。

在函数组件中，我们无法使用this，因此也就无法使用this.state来保存局部状态，Hook出现可以让我们函数组件中定义状态。

Hook API：https://zh-hans.reactjs.org/docs/hooks-reference.html

### 3.1 使用规则

Hook 就是 JavaScript 函数，但是使用它们会有两个额外的规则：

- 只能在**函数最外层**调用 Hook。不要在循环、条件判断或者子函数中调用。
- 只能在 **React 的函数组件**中调用 Hook。不要在其他普通 JavaScript 函数中调用。

### 3.2 State Hook

#### useState(保存组件状态)

useState用于声明一个state变量，该函数只有一个参数，表示声明的变量的初始值。每次调用useState可以创建一个state变量，调用多次可以创建多个state变量。改方法的返回值为state变量及更新该state变量的函数，可以通过数组解构来获取。

```js
// 声明一个叫 “count” 的 state 变量，提供 “setCount” 对应修改 “count” 的方法，并设置 “count” 的初始值为0
const [count, setCount] = useState(0);
```

在pages下创建TestStateHook.js文件

```jsx
// pages/TestStateHook.js
import React from "react";
const { useState } = React;
export default function TestStateHook() {
  const [count, setCount] = useState(0);
  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => { setCount(count + 1) }}>点击</button>
    </div>
  )
}
```

或：上方函数组件的作用与下方类组件的作用一致

```jsx
// pages/TestStateHook.js
import React from "react";
export default class TestStateHook extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }
  render() {
    return (<div>
      <p>You clicked {this.state.count} times</p>
      <button onClick={() => this.setState({
        count: this.state.count + 1
      })} >
        Click me
      </button>
    </div>
    );
  }
}
```

在App.js中引入并使用该TestStateHook组件

```jsx
// App.js
import TestStateHook from './pages/TestStateHook'
// ....
export default function App() {
  return <div>
    <TestStateHook></TestStateHook>
  </div> 
}
// ....
```

结果如下

![image-20220707110952764](image/image-20220707110952764.png)

```js
// 声明多个 state 变量！
const [age, setAge] = useState(42);
const [fruit, setFruit] = useState('banana');
const [todos, setTodos] = useState([{ text: 'Learn Hooks' }]);
```

### 3.3 Effect Hook

为什么使用EffectHook？在函数组件主体内(这里指在 React 渲染阶段)改变 DOM、添加订阅、设置定时器、记录日志以及执行其他包含副作用的操作都是不被允许的，因为这可能会产生莫名其妙的 bug 并破坏 UI 的一致性。

#### useEffect(处理副作用)

Effect Hook 可以让你在函数组件中执行副作用操作。useEffect 就是一个 Effect Hook， 给函数组件增加了操作副作用的能力。它跟 class 组件中的 componentDidMount、 componentDidUpdate 和 componentWillUnmount 具有相同的用途，只不过被合并成了一个 API。

```js
useEffect(() => {
  document.title = `You clicked ${count} times`;
},['count']);
```

useEffect这个函数可以接收两个参数，第一个为函数；第二个为数组(可省略)。对于第二个参数， 如果你传入了一个空数组( [] )，effect 内部的 props 和 state 就会一直持有其初始值。可以向数组中添加需要监听的state，当该state发生变化会引起useEffect重新执行。useEffect 在 渲染时是异步执行，并且要等到浏览器将所有变化渲染到屏幕后才会被执行。

跟 `useState` 一样，你可以在组件中多次使用 `useEffect` 。

```js
useEffect(() => {
  document.title = `You clicked ${count} times`;
},['count']);
useEffect(() => {
  // 发送请求获取数据
  axios.get(`/articles/${id}`).then(res => {
  	console.log(res);
	})
},['id']);
```

通过使用 Hook，你可以把组件内相关的副作用组织在一起（例如创建订阅及取消订阅），而不要把它们拆分到不同的生命周期函数里。

#### useLayoutEffect(同步执行副作用)

useLayoutEffect其函数签名与 useEffect 相同，其调用时机和原来的componentDidMount、componentDidUpdate 一致，它会在所有的 DOM 变更之后**同步调用** effect。可以使用它来读取 DOM 布局并同步触发重渲染。在浏览器执行绘制之前， useLayoutEffect 内部的更新计划将被同步刷新，会阻塞页面渲染。而useEffect是会在整个页面渲染完才会调用的代码，尽可能使用标准的 useEffect 以避免阻塞视觉更新。

在实际使用时如果想避免**页面抖动**(在 useEffect 里修改DOM很有可能出现)的话，可以把需要操作DOM的代码放在 useLayoutEffect 里。在这里做dom操作，这些dom修改会和 react 做出的更改一起被一次性渲染到屏幕 上，只有一次回流、重绘的代价。

#### 示例

在pages下新建TestEffectHook.js文件

```jsx
//pages/TestEffectHook.js
import React, { useState, useEffect } from 'react';
export default function TestEffectHook() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    document.title = `You clicked ${count} times`;
  });
  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}
```

或：上方函数组件的作用与下方类组件的作用一致

缺点：很多情况下，我们希望在组件加载和更新时执行同样的操作。从概念上说，我们希望它在每次渲染之后执行 —— 但 React 的 class 组件没有提供这样的方法。即使我们提取出一个方法，我们还是要在两个地方调用它。

```jsx
//pages/TestEffectHook.js
import React from "react";
export default class TestEffectHook extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }

  componentDidMount() {
    document.title = `You clicked ${this.state.count} times`;
  }
  componentDidUpdate() {
    document.title = `You clicked ${this.state.count} times`;
  }
  render() {
    return (
      <div>
        <p>You clicked {this.state.count} times</p>
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>
          Click me
        </button>
      </div>
    );
  }
}
```

在App.js中引入并使用该TestEffectHook组件

```jsx
// App.js
import TestEffectHook from './pages/TestEffectHook'
// ....
export default function App() {
  return <div>
    <TestEffectHook></TestEffectHook>
  </div> 
}
// ....
```

结果如下，注意选项卡的标题区域内容。

![image-20220707111907938](image/image-20220707111907938.png)

#### 无需清除的 effect

有时候，我们只想在 React 更新 DOM 之后运行一些额外的代码。比如发送网络请求，手动变更DOM，记录日志，这些都是常⻅的无需清除的操作。因为我们在执行完这些操作之后， 就可以忽略他们了。默认情况下，effect在第一次渲染之后和每次更新之后都会执行。

```jsx
useEffect(() => {
	document.title = `You clicked ${count} times`;
});
```

#### 需要清除的 effect

有些副作用是需要清除的。例如订阅外部数据源、渲染图表。这种情况下，清除工作是非常重要的，可以防止引起内存泄露！如果你的 effect 返回一个函数，React 将会在执行清除操作时调用它。

```js
useEffect(() => {
  function handleStatusChange(status) {
  }
	return function cleanup() { };
});
```

![image-20220707113457875](image/image-20220707113457875.png)

### 3.4 其他Hook

#### useMemo(记忆组件)

`useMemo(() => fn, deps)`相当于`useCallback(fn, deps)`。

返回一个 [memoized](https://en.wikipedia.org/wiki/Memoization) 值。

把“创建”函数和依赖项数组作为参数传入 `useMemo`，它仅会在某个依赖项改变时才重新计算 memoized 值。这种优化有助于避免在每次渲染时都进行高开销的计算。

传入 `useMemo` 的函数会在渲染期间执行。请不要在这个函数内部执行不应该在渲染期间内执行的操作，诸如副作用这类的操作属于 `useEffect` 的适用范畴，而不是 `useMemo`。

如果没有提供依赖项数组，`useMemo` 在每次渲染时都会计算新的值。

```js
const memoizedValue = useMemo(() => computeExpensiveValue(a, b), [a, b]);
```

与useEffect有点类似，只有useMemo中的第二个参数数组内变量发生变化的时候，才会去重新执行expensive方法。其功能类似vue中的计算属性。

在pages下新建TestDemoHook.js文件

```jsx
// pages/TestDemoHook.js
import { useState, useMemo } from 'react'
export default function TestDemoHook() {
  const [num, setNum] = useState(0);
  const [result, setResult] = useState(0); 
  let total = useMemo(() => {
    console.log('computed...', Math.random());
    setResult(result + num);
    return result;
  }, [num]);
  return (<div>
    <h2>计数器</h2>
    <div>上次结果 : {total}</div>
    <div>本次结果 : {result}</div>
    <div>num : {num}</div>
    <div><button onClick={() => { setNum(num + 1) }}>change</button></div>
  </div>)
}
```

在App.js中引入并使用该TestDemoHook组件

```jsx
// App.js
import TestDemoHook from './pages/TestDemoHook'
// ....
export default function App() {
  return <div>
    <TestDemoHook></TestDemoHook>
  </div> 
}
// ....
```

结果如下

![image-20220707142804017](image/image-20220707142804017.png)

#### useCallback(记忆函数)

防止因为组件重新渲染，导致方法被重新创建，起到缓存的作用，只有第二个参数变化了，才重新声明一次。

`useCallback(fn, deps)` 相当于 `useMemo(() => fn, deps)`。

返回一个 memoized 回调函数。

把内联回调函数及依赖项数组作为参数传入 `useCallback`，它将返回该回调函数的 memoized 版本，该回调函数仅在某个依赖项改变时才会更新。当你把回调函数传递给经过优化的并使用引用相等性去避免非必要渲染（例如 `shouldComponentUpdate`）的子组件时，它将非常有用。

在pages下新建TestCallback.js文件

```jsx
// pages/TestCallback.js
import { useCallback, useState } from 'react'
export default function TestCallback() {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  const memoizedCallback = useCallback(
    () => {
      // doSomething(a, b);
      console.log(a, b);
    },
    [a, b],
  );
  // 只有a,b改变了才会重新声明该函数
  // 如果传入空数组，在第一次创建后被缓存，如果a,b改变了，获取的是旧值
  // 如果没有传第二个参数，那么每次都会重新声明该函数，拿的是新值
  return (<div>
    <button onClick={() => { memoizedCallback() }}>useCallback测试</button>
    <button onClick={() => { setA(100) }}>更改a的值</button>
    <button onClick={() => { setB(100) }}>更改b的值</button>
  </div>)
}
```

在App.js中引入并使用该TestCallback组件

```jsx
// App.js
import TestCallback from './pages/TestCallback'
// ....
export default function App() {
  return <div>
    <TestCallback></TestCallback>
  </div> 
}
// ....
```

> useDemo与useCallback的区别：两者非常相似，useDemo会执行第一个参数函数，并返回执行结果，useCallback不执行第一个参数函数。
>
> useDemo更适合经过函数计算得到一个确定的值，比如记忆组件。
>
> useCallback常用记忆事件函数，生成记忆后的事件函数并传递给子组件使用。

#### useRef(保存引用值)

```js
const refContainer = useRef(initialValue);
```

`useRef` 返回一个可变的 ref 对象，其 `.current` 属性被初始化为传入的参数（`initialValue`）。返回的 ref 对象在组件的整个生命周期内持续存在。

```jsx
function TextInputWithFocusButton() {
  const inputEl = useRef(null);
  const onButtonClick = () => {
    // `current` 指向已挂载到 DOM 上的文本输入元素
    inputEl.current.focus();
  };
  return (
    <>
      <input ref={inputEl} type="text" />
      <button onClick={onButtonClick}>Focus the input</button>
    </>
  );
}
```

本质上，`useRef` 就像是可以在其 `.current` 属性中保存一个可变值的“盒子”。

### 3.4 自定义Hook

通过自定义 Hook，可以将组件逻辑提取到可重用的函数中。

自定义 Hook 是一个函数，其名称务必以 “`use`” 开头，函数内部可以调用其他的 Hook。

在pages下创建CustomHook.js文件

```jsx
// pages/CustomHook.js
import React, { useEffect, useState } from 'react'
// 声明自定义hook函数，可正常的传参
function useClock(num) {
  console.log(num);
  let [date, setDate] = useState(new Date());
  useEffect(() => {
    const timmer = setInterval(() => {
      setDate(new Date)
    }, 1000); return () => {
      clearInterval(timmer)
    }
  }, [])
  return date;
}
export default function CustomHook() {
  // 使用自定义hook函数，还可以在某个函数组件内使用
  return <div>{useClock(1).toLocaleTimeString()}</div>
}
```

在App.js中引入并使用该CustomHook组件

```jsx
// App.js
import CustomHook from './pages/CustomHook'
// ....
export default function App() {
  return <div>
    <CustomHook></CustomHook>
  </div> 
}
// ....
```

结果如下

![image-20220707153632045](image/image-20220707153632045.png)





# 第四章

学习目标：

+ antd安装
+ 表格组件
+ 表单组件

## 1 antd组件库

`antd` 是基于 Ant Design 设计体系的 React UI 组件库，主要用于研发企业级中后台产品。

Ant Design 组件库官网：https://ant.design/index-cn

### 1.1 特性

- 🌈 提炼自企业级中后台产品的交互语言和视觉风格。
- 📦 开箱即用的高质量 React 组件。
- 🛡 使用 TypeScript 开发，提供完整的类型定义文件。
- ⚙️ 全链路开发和设计工具体系。
- 🌍 数十个国际化语言支持。
- 🎨 深入每个细节的主题定制能力。

### 1.2 安装

新创建create-react-app脚手架项目

```shell
# 如果之前安装过create-react-app，要先进行卸载 
$ npm uninstall -g create-react-app
# 创建好项目后，依赖自动下载好了，不用再下载项目的依赖了
$ npx create-react-app my-app2
$ cd my-app2
$ npm start
# 启动之后，在http://localhost:3000端口上访问react脚手架的项目
```

在my-app2内部安装antd组件库

```shell
# 停止项目安装第三方的antd组件库
$ npm install antd --save
```

`antd` 默认支持基于 ES modules 的 tree shaking，对于 js 部分，直接引入 `import { Button } from 'antd'` 就会有按需加载的效果。

### 1.3 引入及使用

修改 `src/App.js`，引入 antd 的按钮组件。

```jsx
import React from 'react';
import { Button } from 'antd';
import './App.css';

const App = () => (
  <div className="App">
    <Button type="primary">Button</Button>
  </div>
);

export default App;
```

修改 `src/App.css`，在文件顶部引入 `antd/dist/antd.css`。

```css
@import '~antd/dist/antd.css';
```

项目运行效果

![image-20220707155337275](image/image-20220707155337275.png)

组件库：https://ant.design/components/button-cn/

![image-20220707161141258](image/image-20220707161141258.png)



### 1.4 高级配置

如果需要对 create-react-app 的默认配置进行自定义，我们可以使用 [craco](https://github.com/gsoft-inc/craco) （一个对 create-react-app 进行自定义配置的社区解决方案）。

现在我们安装 craco 并修改 `package.json` 里的 `scripts` 属性。

```shell
$ npm install @craco/craco --save
```

```json
/* package.json */
"scripts": {
-   "start": "react-scripts start",
-   "build": "react-scripts build",
-   "test": "react-scripts test",
+   "start": "craco start",
+   "build": "craco build",
+   "test": "craco test",
}
```

然后在项目根目录创建一个 `craco.config.js` 用于修改默认配置。

```js
/* craco.config.js */
module.exports = {
  // ...
};
```

#### 自定义主题

按照 [配置主题](https://ant.design/docs/react/customize-theme-cn) 的要求，自定义主题需要用到类似 [less-loader](https://github.com/webpack-contrib/less-loader/) 提供的 less 变量覆盖功能。我们可以引入 [craco-less](https://github.com/DocSpring/craco-less) 来帮助加载 less 样式和修改变量。

首先把 `src/App.css` 文件修改为 `src/App.less`，然后修改样式引用为 less 文件。

```shell
/* src/App.js */
- import './App.css';
+ import './App.less';
```

```shell
/* src/App.less */
- @import '~antd/dist/antd.css';
+ @import '~antd/dist/antd.less';
```

然后安装 `craco-less` 并修改 `craco.config.js` 文件如下。

```shell
$ npm install craco-less --save
```

```js
// craco.config.js
const CracoLessPlugin = require('craco-less');

module.exports = {
  plugins: [
    {
      plugin: CracoLessPlugin,
      options: {
        lessLoaderOptions: {
          lessOptions: {
            modifyVars: { '@primary-color': '#1DA57A' },
            javascriptEnabled: true,
          },
        },
      },
    },
  ],
};
```

这里利用了 [less-loader](https://github.com/webpack/less-loader#less-options) 的 `modifyVars` 来进行主题配置，变量和其他配置方式可以参考 [配置主题](https://ant.design/docs/react/customize-theme-cn) 文档。修改后重启 `npm run start`，如果看到一个绿色的按钮就说明配置成功了。![image-20220707160856793](image/image-20220707160856793.png)



## 2 表格组件

### 2.1 基本应用

表格的应用非常简单，可以接收至少3个参数：dataSource数据源，columns列定义，rowKey。常见的api如下：

| 属性       | 说明                                                         |      |
| ---------- | ------------------------------------------------------------ | ---- |
| dataSource | 数据数组                                                     |      |
| columns    | title 列头显示文字<br />className 列样式类名<br />align 设置列的对齐方式 left` |`right` |`center<br />dataIndex 列数据在数据项中对应的路径，支持通过数组查询嵌套路径，类似于el中的prop<br /> render 自定义渲染函数，function(text, record, index) {}。参数分别  为:当前列、当前行、索引<br />width 列宽度 |      |
| bordered   | 是否展示外边框和列边框 true `|` false                        |      |
| rowKey     | 表格行 key 的取值，可以是字符串或一个函数                    |      |
| loading    | 页面是否加载中                                               |      |
| size       | 表格大小，default` | `middle` | `small                       |      |
| onChange   | 分页、排序、筛选变化时触发                                   |      |
| pagination | 分页器                                                       |      |

具体示例：

```jsx
// pages/MyTable.js
import React from 'react'
import { Space, Button, Table } from 'antd'
export default class MyTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      articles: {
        "page": 1,
        "pageSize": 5,
        "total": 17,
        "list": [
          {
            "id": 92,
            "title": "詹姆斯",
            "content": "sss",
            "publishTime": 1623120693537,
            "readTimes": 0,
            "status": "未审核",
            "authorId": 2,
            "categoryId": 10,
          },
          {
            "id": 87,
            "title": "test",
            "content": "<p>testdvxd</p>",
            "publishTime": 1622021870837,
            "readTimes": 0,
            "status": "审核通过",
            "projectId": null,
            "authorId": 91,
            "categoryId": null,
          },
          {
            "id": 85,
            "title": "智慧农机管理系统",
            "content": "hello",
            "publishTime": 1614302564828,
            "readTimes": 0,
            "status": "审核通过",
            "authorId": 25,
            "categoryId": 4,
          },
          {
            "id": 84,
            "title": "智慧农机管理系统",
            "content": "智慧农机管理系统内容",
            "publishTime": 1614302564567,
            "readTimes": 0,
            "status": "审核通过",
            "authorId": 25,
            "categoryId": 4,
          },
          {
            "id": 83,
            "title": "温室大棚环境远程监控系统",
            "content": "内容",
            "publishTime": 1614302450964,
            "readTimes": 0,
            "status": "推荐",
            "authorId": 25,
            "categoryId": 3,
          }
        ]
      },
    };
  }
  render() {
    const columns = [
      { title: '标题', dataIndex: 'title', key: 'title' },
      { title: '发布时间', dataIndex: 'publishTime', key: 'publishTime' },
      { title: '状态', dataIndex: 'status', key: 'status' },
      { title: '作者', dataIndex: 'authorId', key: 'authorId' }, {
        title: '操作', dataIndex: 'id',
        key: 'action', align: 'center',
        render: (text, record) => (
          <Space size="middle" align="center">
            <a>修改</a>
            <a>删除</a>
          </Space>),
      }]
    return (<div>
      <h2>文章管理</h2>
      <Button type="primary">发布</Button>
      <Table rowKey={record => record.id} size="small" dataSource={this.state.articles.list} columns={columns} />;
    </div>)
  }
}
```

在App.js中引入并使用该MyTable组件

```jsx
// App.js
import MyTable from './pages/MyTable'
// ....
export default function App() {
  return <div>
    <MyTable></MyTable>
  </div> 
}
// ....
```

结果如下

![f](image/image-20220707172018779.png)

注意：如果我们在componentDidMount中进行ajax，当组件切换的时候可能出现ajax响应还未回来，待响应回来后还需setState，这便引起了异常。

```js
componentWillUnmount(){ 
  this.setState = ()=>false;
}
```

### 2.2 分页功能

修改MyTable组件为如下内容，重点关注表格的pagination属性，及分页变化的事件处理程序pageChangeHandler。

```jsx
import React from 'react'
import { Space, Button, Table } from 'antd'
export default class MyTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      articles: {
        "page": 1,
        "pageSize": 5,
        "total": 17,
        "list": [
          {
            "id": 92,
            "title": "詹姆斯",
            "content": "sss",
            "publishTime": 1623120693537,
            "readTimes": 0,
            "status": "未审核",
            "authorId": 2,
            "categoryId": 10,
          },
          {
            "id": 87,
            "title": "test",
            "content": "<p>testdvxd</p>",
            "publishTime": 1622021870837,
            "readTimes": 0,
            "status": "审核通过",
            "projectId": null,
            "authorId": 91,
            "categoryId": null,
          },
          {
            "id": 85,
            "title": "智慧农机管理系统",
            "content": "hello",
            "publishTime": 1614302564828,
            "readTimes": 0,
            "status": "审核通过",
            "authorId": 25,
            "categoryId": 4,
          },
          {
            "id": 84,
            "title": "智慧农机管理系统",
            "content": "智慧农机管理系统内容",
            "publishTime": 1614302564567,
            "readTimes": 0,
            "status": "审核通过",
            "authorId": 25,
            "categoryId": 4,
          },
          {
            "id": 83,
            "title": "温室大棚环境远程监控系统",
            "content": "内容",
            "publishTime": 1614302450964,
            "readTimes": 0,
            "status": "推荐",
            "authorId": 25,
            "categoryId": 3,
          }
        ]
      },
    };
  }
  pageChangeHandler = (page, pageSize) => {
    this.setState({
      articles: {
        ...this.state.articles,
        page: page
      }
    })
    console.log('分页变化', page, pageSize);
  }
  render() {
    const columns = [
      { title: '标题', dataIndex: 'title', key: 'title' },
      { title: '发布时间', dataIndex: 'publishTime', key: 'publishTime' },
      { title: '状态', dataIndex: 'status', key: 'status' },
      { title: '作者', dataIndex: 'authorId', key: 'authorId' }, {
        title: '操作', dataIndex: 'id',
        key: 'action', align: 'center',
        render: (text, record) => (
          <Space size="middle" align="center">
            <a>修改</a>
            <a>删除</a>
          </Space>),
      }]
    return (<div>
      <h2>文章管理</h2>
      <Button type="primary">发布</Button>
      <Table pagination={{
        current: this.state.articles.page,
        pageSize: this.state.articles.pageSize,
        total: this.state.articles.total,
        onChange: this.pageChangeHandler
      }}
        rowKey={record => record.id}
        size="small"
        dataSource={this.state.articles.list}
        columns={columns}
      />;
    </div>)
  }
}
```

结果：

![image-20220707172901327](image/image-20220707172901327.png)









## 3 表单组件

### 3.1 基本应用

表单用于收集用户信息，我们主要使用表单的默认值、收集表单数据功能。我们常把表单组件封装到函数组件中。这里主要用到Form组件，该组件常⻅属性如下:

| 属性             | 解释                                                         |
| ---------------- | ------------------------------------------------------------ |
| name             | 表单名称，会作为表单字段 `id` 前缀使用                       |
| form             | 经 `Form.useForm()` 创建的 form 控制实例，不提供时会自动创建 |
| colon            | 配置 Form.Item 的 `colon` 的默认值。表示是否显示 label 后面的冒号 (只有在属性 layout 为 horizontal 时有效) |
| labelAlign       | label 标签的文本对齐方式，left` |`right                      |
| layout           | 表单布局，horizontal` |`vertical` |`inline                   |
| size             | 设置字段组件的尺寸（仅限 antd 组件），small` |`middle` |`large |
| initialValues    | 表单默认值，只有初始化以及重置时生效                         |
| onFinish         | 提交表单且数据验证成功后回调事件，function(values)           |
| onFinishFailed   | 提交表单且数据验证失败后回调事件，function({ values, errorFields, outOfDate }) |
| validateMessages | 验证提示模板，示例见下                                       |

```jsx
const validateMessages = {
  required: "'${name}' 是必选字段",
  // ...
};

<Form validateMessages={validateMessages} />;
```

表单元素的子元素通常是Form.Item，用于数据双向绑定、校验、布局等

| 属性       | 说明                                                         |
| ---------- | ------------------------------------------------------------ |
| label      | 标签的文本                                                   |
| name       | 字段名，支持数组，也是最终表单数据对象内的属性名             |
| rules      | 校验规则，设置字段的校验逻辑，示例见下                       |
| wrapperCol | 需要为输入控件设置布局样式时，你可以通过 Form 的 wrapperCol 进行统一 设置 |

```jsx
<Form.Item
	label="Username"
	name="username"
	rules={[{ required: true, message: 'Please input your username!' }]}
>
  <Input />
</Form.Item>
```

### 3.2 示例

在pages下新建MyForm.js文件，内容如下：

```jsx
import { Form, Input, Button } from 'antd'
function MyForm() {
  const onFinish = (values) => {
    console.log('Success:', values);
  };
  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };
  return (
    <Form
      name="basic" initialValues={{
        title: '默认标题',
        content: '默认内容'
      }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed} >
      <Form.Item label="标题"
        name="title" rules={[
          {
            required: true,
            message: 'Please input content title!',
          },]}
      >
        <Input />
      </Form.Item>
      <Form.Item label="内容" name="content" rules={[
        {
          required: true,
          message: 'Please input article content!',
        },]}
      >
        <Input.TextArea />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          提交
        </Button>
      </Form.Item>
    </Form>
  )
}
export default MyForm;
```

在App.js中引入并使用该MyForm组件

```jsx
// App.js
import MyForm from './pages/MyForm'
// ....
export default function App() {
  return <div>
    <MyForm></MyForm>
  </div> 
}
// ....
```

结果如下

![image-20220708174018871](image/image-20220708174018871.png)

![image-20220712093357584](image/image-20220712093357584.png)

### 3.3 模态框表单

antd推荐使用 Form.useForm 创建表单数据域进行控制。将Form嵌套在Modal中， Modal常⻅的属性如下:

| 属性       | 说明                                 |
| ---------- | ------------------------------------ |
| visible    | 对话框是否可⻅                       |
| title      | 标题                                 |
| okText     | 确认按钮文字                         |
| cancelText | 取消按钮文字                         |
| onCancel   | 点击遮罩层或右上⻆叉或取消按钮的回调 |
| onOk       | 点击确定回调                         |
| width      | 宽度                                 |

子：表单模态框，pages/ FormModal.js

```jsx
// pages/FormModal.js
import { Modal, Form, Input } from 'antd'
const FormModal = ({ visible, onCreate, onCancel }) => {
  const [form] = Form.useForm();
  return (
    <div>
      <Modal
        visible={visible} title="表单标题" okText="保存"
        cancelText="取消" onCancel={onCancel}
        onOk={() => {
          form.validateFields().then((values) => {
            form.resetFields();
            onCreate(values);
          })
            .catch((info) => {
              console.log('Validate Failed:', info);
            });
        }}
      >
        <Form
          form={form} layout="vertical" name="form_in_modal" initialValues={{
            title: '默认标题', content: '默认内容'
          }}
        >
          <Form.Item
            label="标题" name="title" rules={[
              {
                required: true,
                message: 'Please input content title!',
              },]}
          >
            <Input />
          </Form.Item>
          <Form.Item label="内容" name="content" rules={[
            {
              required: true,
              message: 'Please input article content!',
            },]}
          >
            <Input.TextArea />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
export default FormModal;
```

父：MyManage，内部使用表单模态框，pages/MyManage.js，使用函数组件或者类组件

函数组件

```jsx
// pages/MyManage.js
import React, { useState } from 'react'
import FormModal from './FormModal';

const MyManage = () => {
  let [visible, setVisible] = useState(false)
  let createHandler = (values) => {
    console.log('模态框内表单的数据', values);
  }
  let cancelHandler = () => {
    console.log('模态框关闭的回调函数');
    setVisible(false)
  }
  let changeVisible = () => {
    setVisible(true)
  }

  return <div>
    <button onClick={changeVisible}>打开模态框</button>
    <FormModal visible={visible} onCreate={createHandler} onCancel={cancelHandler}></FormModal>
  </div>
}
export default MyManage 
```

类组件

```jsx
// pages/MyManage.js
import React from 'react'
import FormModal from './FormModal';
class MyManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false
    };
  }
  createHandler = (values) => {
    console.log('模态框内表单的数据', values);
  }
  cancelHandler = () => {
    console.log('模态框关闭的回调函数');
    this.setState({
      visible: false
    })
  }
  changeVisible = () => {
    this.setState({
      visible: true
    })
  }
  render() {
    return <div>
      <button onClick={this.changeVisible}>打开模态框</button>
      <FormModal visible={this.state.visible} onCreate={this.createHandler} onCancel={this.cancelHandler}></FormModal>
    </div>
  }
}
export default MyManage
```

在App.js中引入并使用该MyManage组件

```jsx
// App.js
import MyManage from './pages/MyManage'
// ....
export default function App() {
  return <div>
    <MyManage></MyManage>
  </div> 
}
// ....
```

结果：

![image-20220712104151039](image/image-20220712104151039.png)

![image-20220712104247792](image/image-20220712104247792.png)

## 4 提示框

### 4.1 全局提示Message

message具有success、error、warning、info、loading等方法，分别表示成功提示、错误提示、警告提示、普通提示、加载提示。

组件提供了一些静态方法，使用方式和参数如下：

- `message.success(content, [duration], onClose)`
- `message.error(content, [duration], onClose)`
- `message.info(content, [duration], onClose)`
- `message.warning(content, [duration], onClose)`
- `message.warn(content, [duration], onClose)`   // alias of warning
- `message.loading(content, [duration], onClose)`

![image-20220712104742079](image/image-20220712104742079.png)

使用，pages/MyMessage.js

```jsx
import { message } from 'antd'
const MyMessage = () => {
  return <div>
    <button onClick={() => { message.success('This is a success message', 1); }}>Message提示</button>
  </div>
}
export default MyMessage;
```

在App.js中引入并使用该组件

```jsx
// App.js
import MyMessage from './pages/MyMessage'
// ....
export default function App() {
  return <div>
    <MyMessage></MyMessage>
  </div> 
}
// ....
```

效果：点击按钮后弹出全局提示，并在1s后关闭该提示。

![image-20220712104926257](image/image-20220712104926257.png)

### 4.2 通知提示框

与message类似，notification也具有success、error、warning、info等方法。

- `notification.success(config)`
- `notification.error(config)`
- `notification.info(config)`
- `notification.warning(config)`
- `notification.warn(config)`
- `notification.open(config)`
- `notification.close(key: String)`
- `notification.destroy()`

参数config中的常用属性如下：

| 属性        | 说明                                                         |
| ----------- | ------------------------------------------------------------ |
| message     | 通知提醒标题，必选                                           |
| description | 通知提醒内容，必选                                           |
| duration    | 默认 4.5 秒后自动关闭，配置为 null 则不自动关闭              |
| placement   | 弹出位置，可选 `topLeft` `topRight` `bottomLeft` `bottomRight`，默认topRight |
| top         | 消息从顶部弹出时，距离顶部的位置，单位像素，默认24           |
| onClick     | 点击通知时触发的回调函数                                     |
| onClose     | 当通知关闭时触发                                             |

使用，在pages/MyMessage.js中添加如下内容

```jsx
import { notification } from 'antd';
// ...
<button onClick={() => {
    notification.success({
      message: '我是标题',
      description: '我是描述信息',
      onClick() {
          console.log('点击我了');
      }
    });
  }}>
  Notification通知提醒框
</button>
// ...
```

效果

![image-20220712110407531](image/image-20220712110407531.png)



### 4.3 确认对话框

安装图标库组件

```shell
$ npm install --save @ant-design/icons --legacy-peer-deps
# 或者
$ npm install --save @ant-design/icons
```

引入图表

```js
import { ExclamationCircleOutlined } from '@ant-design/icons';
```

确认对话框需要使用模态框来完成其功能，在pages/MyMessage.js中添加如下内容

```jsx
import { Modal } from 'antd'
import { ExclamationCircleOutlined } from '@ant-design/icons';
const { confirm } = Modal;
// ....
<button onClick={() => {
    confirm({
      title: 'Do you Want to delete these items?',
      icon: <ExclamationCircleOutlined />,
      content: 'Some descriptions',
      onOk() {
        console.log('OK');
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  }}>
  确认框
</button>
// ....
```

效果

![image-20220712153157215](image/image-20220712153157215.png)

## 5 综合案例

行学天下⻔户系统开发

# 第五章

学习目标：

+ redux介绍
+ redux 核心概念
+ redux hello world
+ redux-saga

## 1 redux介绍

学习网站：http://cn.redux.js.org/introduction/getting-started/、https://react-redux.js.org/

学习资源：http://cn.redux.js.org/introduction/learning-resources

Redux 是 JavaScript 应用的状态容器，提供可预测的状态管理。可以开发出行为稳定可预测的应用，运行于不同的环境（客户端、服务器、原生应用），并且易于测试。Redux 除了和 React 一起用外，还支持其它界面库。它体小精悍（只有2kB，包括依赖），却有很强大的插件扩展生态。

**Redux 是一个使用叫做“action”的事件来管理和更新应用状态的模式和工具库** 它以集中式Store（centralized store）的方式对整个应用中使用的状态进行集中管理，其规则确保状态只能以可预测的方式更新。

**Redux 提供的模式和工具使您更容易理解应用程序中的状态何时、何地、为什么以及如何更新，以及当这些更改发生时您的应用程序逻辑将如何表现**. Redux 指导您编写可预测和可测试的代码，这有助于让您确信您的应用程序将按预期工作。

类似于vuex  但是不同于vuex，可以对状态进行管理。

随着 JavaScript 单页应用开发日趋复杂，**JavaScript 需要管理比任何时候都要多的 state （状态）**。 这些 state 可能包括服务器响应、缓存数据、本地生成尚未持久化到服务器的数据，也包括 UI 状态，如激活的路由，被选中的标签，是否显示加载动效或者分页器等等。

Redux 是⼀个有⽤的架构，但不是⾮⽤不可。事实上，⼤多数情况，你可以不⽤它，只⽤ React 就够了。 

Redux 在以下情况下更有用： 

- 在应用的大量地方，都存在大量的状态
- 应用状态会随着时间的推移而频繁更新
- 更新该状态的逻辑可能很复杂
- 中型和大型代码量的应用，很多人协同开发

+ 不同身份的⽤户有不同的使⽤⽅式（⽐如普通⽤户和管理员） 
+ 与服务器⼤量交互，或者使⽤了WebSocket 
+ View要从多个来源获取数据 
+ 某个组件的状态，需要共享某个状态需要在任何地⽅都可以拿到  
+ ⼀个组件需要改变全局状态 
+ ⼀个组件需要改变另⼀个组件的状态 

> 整个应用程序所需的全局状态应该放在 Redux store 中。而只在一个地方用到的状态应该放到组件的 state。
>
> 在 React + Redux 应用中，你的全局状态应该放在 Redux store 中，你的本地状态应该保留在 React 组件中。

## 2 Redux 库和工具

+ Redux：Redux 是一个小型的独立 JS 库
+ React-Redux：Redux 可以集成到任何的 UI 框架中，其中最常见的是 React 。[**React-Redux**](https://react-redux.js.org/) 是官方包，它可以让 React 组件访问 state 和下发 action 更新 store，从而同 Redux 集成起来。
+ Redux Toolkit：[**Redux Toolkit**](https://redux-toolkit.js.org/) 是我们推荐的编写 Redux 逻辑的方法。 它包含我们认为对于构建 Redux 应用程序必不可少的包和函数。 Redux Toolkit 构建在我们建议的最佳实践中，简化了大多数 Redux 任务，防止了常见错误，并使编写 Redux 应用程序变得更加容易。
+ Redux DevTools 扩展：[**Redux DevTools 扩展**](https://github.com/zalmoxisus/redux-devtools-extension) 可以显示 Redux 存储中状态随时间变化的历史记录。这允许您有效地调试应用程序，包括使用强大的技术，如“时间旅行调试”。

> redux 其实是一个第三方 数据状态管理的库，它不仅仅可以和react 结合使用，你也可以把它应用到 vue 中 ， react-redux 其实是帮我们封装了 redux 连接 react 的一些操作，使用 react-redux 可以非常简单的在 react 中使用 redux 来管理我们应用的状态。

学习redux之前应该确保在浏览器中安装了 React 和 Redux DevTools 扩展：

- React DevTools 扩展：
  - [React DevTools Extension for Chrome](https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?hl=en)
  - [React DevTools Extension for Firefox](https://addons.mozilla.org/en-US/firefox/addon/react-devtools/)
- Redux DevTools Extension:
  - [Redux DevTools Extension for Chrome](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=en)
  - [Redux DevTools Extension for Firefox](https://addons.mozilla.org/en-US/firefox/addon/reduxdevtools/)

![image-20220713112710764](image/image-20220713112710764.png)

![image-20220713112931332](image/image-20220713112931332.png)

## 3 单向数据流

计时器的例子：

```jsx
function Counter() {
  // State: a counter value
  const [counter, setCounter] = useState(0)

  // Action: 当事件发生后，触发状态更新的代码
  const increment = () => {
    setCounter(prevCounter => prevCounter + 1)
  }

  // View: UI 定义
  return (
    <div>
      Value: {counter} <button onClick={increment}>Increment</button>
    </div>
  )
}
```

这是一个包含以下部分的自包含应用程序：

- **state**：驱动应用的真实数据源头
- **view**：基于当前状态的 UI 声明性描述
- **actions**：根据用户输入在应用程序中发生的事件，并触发状态更新

单向数据流（one-way data flow）特点：

- 用 state 来描述应用程序在特定时间点的状况
- 基于 state 来渲染出 View
- 当发生某些事情时（例如用户单击按钮），state 会根据发生的事情进行更新，生成新的 state
- 基于新的 state 重新渲染 View



<img src="image/image-20220713141700020.png" alt="image-20220713141700020" style="zoom:50%;" />

然而，当我们有**多个组件需要共享和使用相同state**时，可能会变得很复杂，尤其是当这些组件位于应用程序的不同部分时。有时这可以通过 ["提升 state"](https://reactjs.org/docs/lifting-state-up.html) 到父组件来解决，但这并不总是有效。

解决这个问题的一种方法是从组件中提取共享 state，并将其放入组件树之外的一个集中位置。这样，我们的组件树就变成了一个大“view”，任何组件都可以访问 state 或触发 action，无论它们在树中的哪个位置！

通过定义和分离 state 管理中涉及的概念并强制执行维护 view 和 state 之间独立性的规则，代码变得更结构化和易于维护。

这就是 Redux 背后的基本思想：应用中使用集中式的全局状态来管理，并明确更新状态的模式，以便让代码具有可预测性。

### 深入了解

具体来说，对于 Redux，我们可以将这些步骤分解为更详细的内容：

- 初始启动：
  - 使用最顶层的 root reducer 函数创建 Redux store
  - store 调用一次 root reducer，并将返回值保存为它的初始 `state`
  - 当 UI 首次渲染时，UI 组件访问 Redux store 的当前 state，并使用该数据来决定要呈现的内容。同时监听 store 的更新，以便他们可以知道 state 是否已更改。
- 更新环节：
  - 应用程序中发生了某些事情，例如用户单击按钮
  - dispatch 一个 action 到 Redux store，例如 `dispatch({type: 'counter/increment'})`
  - store 用之前的 `state` 和当前的 `action` 再次运行 reducer 函数，并将返回值保存为新的 `state`
  - store 通知所有订阅过的 UI，通知它们 store 发生更新
  - 每个订阅过 store 数据的 UI 组件都会检查它们需要的 state 部分是否被更新。
  - 发现数据被更新的每个组件都强制使用新数据重新渲染，紧接着更新网页。

<img src="image/理解redux.gif" alt="理解redux.gif" style="zoom:50%;" />

redux工作流

![image-20220715163332612](image/image-20220715163332612.png)

![image-20220715163350558](image/image-20220715163350558.png)

## 4 核心概念

应用的整体全局状态以对象树的方式存放于单个 *store*。 唯一改变状态树（state tree）的方法是创建 *action*，一个描述发生了什么的对象，并将其 *dispatch* 给 store。 要指定状态树如何响应 action 来进行更新，你可以编写纯 *reducer* 函数，这些函数根据旧 state 和 action 来计算新 state。

### 4.1 state

托管给redux管理的状态

```js
let state = { 
	todos:[], 
	params:{} 
} 
```

### 4.2 action

Action 描述当前发⽣的事情。改变 State 的唯⼀办法，就是使⽤ Action。它会运送数据 到 Store。Action 本质上是 JavaScript 普通对象。我们约定，action 内必须使⽤⼀个字符串类型的 type 字段来表示将要执⾏的动作。

`type` 字段是一个字符串，给这个 action 一个描述性的名字，比如`"todos/todoAdded"`。我们通常把那个类型的字符串写成“域/事件名称”，其中第一部分是这个 action 所属的特征或类别，第二部分是发生的具体事情。

action 对象可以有其他字段，其中包含有关发生的事情的附加信息。按照惯例，我们将该信息放在名为 `payload` 的字段中，也可放放到其他属性中，不过最好放到payload中。

一个典型的 action 对象如下所示：

```js
const addTodoAction = {
  type: 'todos/todoAdded',
  payload: 'Buy milk'
}
// action也可如下：
// { type: 'ADD_TODO', text: '去游泳馆' } 
// { type: 'TOGGLE_TODO', index: 1 } 
// { type: 'SET_VISIBILITY_FILTER', filter: 'completed' } 
```

#### Action Creator

**action creator** 是一个创建并返回一个 action 对象的函数。它的作用是让你不必每次都手动编写 action 对象：

```js
const addTodo = text => {
  return {
    type: 'todos/todoAdded',
    payload: text
  }
}
```

### 4.3 reducer(重要)

**reducer** 是一个函数，接收当前的 `state` 和一个 `action` 对象，必要时决定如何更新状态，并返回新状态。函数签名是：`(state, action) => newState`。 可以将 reducer 视为一个事件监听器，它根据接收到的 action（事件）类型处理事件。

> "Reducer" 函数的名字来源是因为它和 [`Array.reduce()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce) 函数使用的回调函数很类似。

Reducer 必需符合以下规则：

- 仅使用 `state` 和 `action` 参数计算新的状态值
- 禁止直接修改 `state`。必须通过复制现有的 `state` 并对复制的值进行更改的方式来做 *不可变更新（immutable updates）*。
- 禁止任何异步逻辑、依赖随机值或导致其他“副作用”的代码

reducer 函数内部的逻辑通常遵循以下步骤：

- 检查 reducer 是否关心这个 action
  - 如果是，则复制 state，使用新值更新 state 副本，然后返回新 state
- 否则，返回原来的 state 不变

#### 声明reducer

```js
const initialState = { value: 0 }

function counterReducer(state = initialState, action) {
  // 检查 reducer 是否关心这个 action
  if (action.type === 'counter/increment') {
    // 如果是，复制 `state`
    return {
      ...state,
      // 使用新值更新 state 副本
      value: state.value + 1
    }
  }
  // 返回原来的 state 不变
  return state
}
```

Reducer 可以在内部使用任何类型的逻辑来决定新状态应该是什么，如 `if/else`、`switch`、循环等等。

> Reducers 指定了应⽤状态的变化如何响应 actions 并发送到 store 的。reducer 只是⼀个 接收 state 和 action，并返回新的 state 的纯函数。

 对于⼤的应⽤来说，不⼤可能仅仅只写⼀ 个这样的函数，所以我们编写很多⼩函数来分别管理 state 的⼀部分： 

```js
// 1.reducer
function todos(state={list:[],loading:false},action){
  switch(action.type){
   case "ADD_TODO":
     return {
       ...state,
       list:state.list.concat(action.payload)
     }
     default:
       return state
  }
} 
```

#### 不可变性 Immutability

"Mutable" 意为 "可改变的"，而 "immutable" 意为永不可改变。

JavaScript 的对象（object）和数组（array）默认都是 mutable 的。如果创建一个对象，可以更改其字段的内容。如果创建一个数组，可以更改其内部内容。即：内存中还是原来对象或数组的引用，但里面的内容变化了。

**Redux 期望所有状态更新都是使用不可变的方式**，如果想要不可变的方式来更新，代码必需先复制原来的 object/array，然后更新它的复制体。JavaScript array/object 的展开运算符（spread operator）可以实现这个目的。

```js
let obj = {};
let arr = [];
// 可变更新
obj.name = 'tom';
arr[0] = 'hello';
// 不可变更新
obj = {
  ...obj,
  age:12
}
arr = [
  ...arr,
  'world'
]

```

#### 应用Reducer

需要先创建⼀个store，然后将store注⼊给react组件，在组件中通过props来访问state以 及通过props来dispatch action。 

```js
import {createStore} from 'redux'
// 一个reducer
export default function todos(state = [], action) {
  switch (action.type) {
    case 'ADD_TODO':
      return state.concat([action.text])
    default:
      return state
  }
}
// 另一个reducer
export default function counter(state = 0, action) {
  switch (action.type) {
    case 'INCREMENT':
      return state + 1
    case 'DECREMENT':
      return state - 1
    default:
      return state
  }
}
// 如果该仓库只用一个reducer,则如下用法
const store=createStore(todos);
// 如果该仓库用多个reducer,则使用combineReducers函数来合并reducer,可以通过combineReducers组合多个Reducer，然后通过createStore来创建状态机。 
const store2=createStore(combineReducers({
  todos,
  counter, 
}));
```

你可以调用 `combineReducers({ todos: todos, counter: counter})` 将 state 结构变为 `{ todos, counter }`。

通常的做法是命名 reducer，然后 state 再去分割那些信息，这样你可以使用 ES6 的简写方法：`combineReducers({ counter, todos })`。这与 `combineReducers({ counter: counter, todos: todos })` 是等价的。

> 在 Redux 中，只有一个 store，但是 `combineReducers` 让你拥有多个 reducer，同时保持各自负责逻辑块的独立性。

### 4.4 store

当前 Redux 应用的状态存在于一个名为 **store** 的对象中。store 是通过传入一个 reducer 来创建的，并且有一个名为 `getState` 的方法，它返回当前状态值。

Store 就是保存数据的地⽅，可以把它看成⼀个容器。整个应⽤只能有⼀个 Store。 Redux 提供createStore这个函数，⽤来⽣成 Store。

```js
// 创建仓库 store并导出
import { createStore } from 'redux';
import reducer from './reducer';
// 将reducer与store绑定，创建store并返回
export default createStore(reducer);
// 如果该仓库用多个reducer,则使用combineReducers函数来合并reducer
const store2=createStore(combineReducers({
	todos,
	counter, 
}));
const store3 = createStore(reducer, 
   window.__REDUX_DEVTOOLS_EXTENSION__ 
  	&& window.__REDUX_DEVTOOLS_EXTENSION__());
```

上方代码中加入window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())是为了能在谷歌浏览器中用redux devtools调试工具。

或者直接使用@reduxjs/toolkit包中的configureStore方法来生成store。

```js
import { configureStore } from '@reduxjs/toolkit'
const store = configureStore({ reducer: counterReducer })
console.log(store.getState())
// {value: 0}
```

仓库创建好了之后，将store引入到需要使用仓库的组件中。

```jsx
import store from './store/index.js'
// 分发动作
store.dispatch({type:'',payload:''})
// 获取仓库数据
store.getState();
```

### 4.5 Dispatch

Redux store 有一个方法叫 `dispatch`。**更新 state 的唯一方法是调用 `store.dispatch()` 并传入一个 action 对象**。 store 将执行所有 reducer 函数并计算出更新后的 state，调用 `getState()` 可以获取新 state。

```js
store.dispatch({ type: 'counter/increment' })
console.log(store.getState())
// {value: 1}
```

**dispatch 一个 action 可以形象的理解为 "触发一个事件"**。发生了一些事情，我们希望 store 知道这件事。 Reducer 就像事件监听器一样，当它们收到关注的 action 后，它就会更新 state 作为响应。

我们通常调用 action creator 来调用 action：

```js
const increment = () => {
  return {
    type: 'counter/increment'
  }
}
// 分发动作
store.dispatch(increment())
console.log(store.getState())
// {value: 2}
```

### 4.6 Selector

**Selector** 函数可以从 store 状态树中提取指定的片段。随着应用变得越来越大，会遇到应用程序的不同部分需要读取相同的数据，selector 可以避免重复这样的读取逻辑。

```js
const selectCounterValue = state => state.value
const currentValue = selectCounterValue(store.getState())
console.log(currentValue)
// 2
```

### 4.7 subscribe(listener)

添加一个变化监听器。每当 dispatch action 的时候就会执行，state 树中的一部分可能已经变化。你可以在回调函数里调用 [`getState()`](http://cn.redux.js.org/api/store#getstate) 来拿到当前 state。你可以在变化监听器里面进行 [`dispatch()`](http://cn.redux.js.org/api/store#dispatchaction)，如果需要解绑这个变化监听器，执行 `subscribe` 返回的函数即可。

参数`listener` (*Function*): 每当 dispatch action 的时候都会执行的回调。state 树中的一部分可能已经变化。你可以在回调函数里调用 [`getState()`](http://cn.redux.js.org/api/store#getstate) 来拿到当前 state。store 的 reducer 应该是纯函数，因此你可能需要对 state 树中的引用做深度比较来确定它的值是否有变化。

返回值(Function): 一个可以解绑变化监听器的函数。

```js
store.subscribe(() => {
  this.setState({
    ...store.getState()
  });
});  //订阅者做的事情
```

具体可参见备忘录案例。

### 4.8 总结

- Redux 是一个管理全局应用状态的库
  - Redux 通常与 React-Redux 库一起使用，把 Redux 和 React 集成在一起
  - Redux Toolkit 是编写 Redux 逻辑的推荐方式
- Redux 使用 "单向数据流"
  - State 描述了应用程序在某个时间点的状态，UI 基于该状态渲染
  - 当应用程序中发生某些事情时：
    - UI dispatch 一个 action
    - store 调用 reducer，随后根据发生的事情来更新 state
    - store 通知 UI state 发生了变化
  - UI 基于新 state 重新渲染
- Redux 有这几种类型的代码
  - *Action* 是有 `type` 字段的纯对象，描述发生了什么
  - *Reducer* 是纯函数，基于先前的 state 和 action 来计算新的 state
  - 每当 dispatch 一个 action 后，*store* 就会调用 root reducer

## 5 安装及使用

### 5.1 安装

自己手动在create-react-app脚手架项目中安装redux

新创建create-react-app脚手架项目

```shell
# 如果之前安装过create-react-app，要先进行卸载 
$ npm uninstall -g create-react-app
# 创建好项目后，依赖自动下载好了，不用再下载项目的依赖了
$ npx create-react-app redux-app
$ cd redux-app
$ npm start
# 启动之后，在http://localhost:3000端口上访问react脚手架的项目
```

在redux-app项目内部安装antd，可不安装antd，使用组件库让页面效果更好一些。

```shell
$ npm install antd --save
```

修改 `src/App.css`，在文件顶部引入 `antd/dist/antd.css`。

```css
@import '~antd/dist/antd.css';
```

在redux-app项目内部安装redux

```shell
$ npm install redux --save   # redux核心
$ npm install --save-dev redux-devtools  # redux开发者工具
```

### 5.2 备忘录案例

在src/store/reducer.js文件中：

```js
// src/store/reducer.js
import util from '../utils/util'
// 函数  reducer
const initState = {
  inputValue: '',
  listData: [{
    text: '备忘录1',
    time: '2019-09-09 09:09:09',
    status: '未完成'
  }, {
    text: '备忘录2',
    time: '2019-09-10 09:09:09',
    status: '已完成'
  }]
};
export default (state = initState, action) => {
  console.log('reducer');
  if (action.type === "TO_CHANGE_INPUT") {
    let obj = {
      ...state,
      inputValue: action.value
    }
    console.log(obj);
    return obj;
    /* return {
      ...state,
      inputValue: action.value
    }; */
  }
  if (action.type === 'TO_ADD') {
    // 修改仓库
    let obj = {
      text: state.inputValue,
      time: util.parseDate(),
      status: '未完成'
    };
    let { listData } = state;
    listData.push(obj);
    return {
      ...state,
      listData,
      inputValue: ''
    }
  }
  if (action.type === "TO_DELETE") {
    let { listData } = state;
    listData = [...listData];
    listData.splice(action.index, 1);
    return {
      ...state,
      listData
    }
  }
  if (action.type === "TO_CHANGE_STATUS") {
    let { listData } = state;
    listData = [...listData];
    listData[action.index].status = '已完成';
    return {
      ...state,
      listData
    }
  }
  return { ...state };

}
```

其中用到了处理时间的函数，在src/utils/util.js中：

```js
// src/utils/util.js
function parseDate() {
  let date = new Date();
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();
  let hours = date.getHours();
  let minutes = date.getMinutes();
  let seconds = date.getSeconds();
  return year + '-' + formatNum(month) + '-' + formatNum(day) + ' ' + formatNum(hours) + ':' + formatNum(minutes) + ':' + formatNum(seconds);
}
function formatNum(num) {
  return num > 10 ? num : ('0' + num);
}
export default {
  parseDate
}
```

reducer创建好了之后，再创建仓库对象，在src/store/index.js文件中：

```js
// src/store/index.js
// 仓库 store
import { createStore } from 'redux';
import reducer from './reducer';
// 将reducer与store绑定，创建store并返回
export default createStore(reducer);
```

至此仓库就创建好了，之后需要将仓库使用起来，以及在组件内分发动作，触发逻辑代码执行，在src/components/ToDo.js文件中：

```jsx
// src/components/ToDo.js
import React, { Component } from 'react';
import { Button, Input, List } from 'antd';
// 引入store
import store from '../store';
class ToDo extends Component {
  constructor(props) {
    super(props);
    this.state = store.getState();
    store.subscribe(this.changeState);  //订阅者做的事情
  }
  changeState = () => {
    this.setState({
      ...store.getState()
    });
  }
  inputChange = (e) => {
    // 获取input数据，更改store中的数据
    let action = {
      type: 'TO_CHANGE_INPUT',
      value: e.target.value
    };
    // 分发action
    store.dispatch(action);
    // console.log(this.state, '------');
  }
  // 添加
  toAdd = () => {
    let action = {
      type: 'TO_ADD'
    };
    store.dispatch(action);
  }
  // 删除
  toDelete = (index) => {
    // console.log(index);
    let action = {
      type: 'TO_DELETE',
      index
    };
    store.dispatch(action);
  }
  // 完成
  toChangeStatus = (index) => {
    let action = {
      type: 'TO_CHANGE_STATUS',
      index
    };
    store.dispatch(action);
  }
  render() {
    return (
      <div style={{ padding: 20 }}>
        <h2>备忘录</h2>
        {/* {JSON.stringify(this.state)} */}
        <div>
          <Input type="text" value={this.state.inputValue} onChange={this.inputChange} style={{ width: 200 }} />
          <Button type="primary" onClick={this.toAdd}>添加</Button>
        </div>
        <div style={{ marginTop: 10 }}>
          {/* 展示数组 */}
          <List size="small"
            bordered
            dataSource={this.state.listData}
            renderItem={(item, index) => (
              <List.Item>
                <List.Item.Meta
                  title={<span style={{ color: item.status === '未完成' ? 'red' : 'green' }}>[{item.status}]{item.text}&nbsp;&nbsp;{item.time}</span>}
                />
                <div>
                  {
                    item.status === '未完成' && <Button type="link" onClick={this.toChangeStatus.bind(this, index)}>完成</Button>
                  }
                  <Button type="link" onClick={this.toDelete.bind(this, index)}>删除</Button>
                </div>
              </List.Item>
            )}
          />
        </div>
      </div>
    );
  }
}

export default ToDo;
```

在App.js中引入并使用该组件

```jsx
// App.js
import ToDo from './components/ToDo';
// ....
export default function App() {
  return <div>
    <ToDo></ToDo>
  </div> 
}
// ....
```

效果：

![image-20220718100312953](image/image-20220718100312953.png)

## 6 ReduxAPI

### 6.1 顶级API

createStore(reducer, [preloadedState], [enhancer])  创建仓库

combineReducers(reducers) 合并reducer

applyMiddleware(...middlewares)  应用中间件

### 6.2 store API

store.getState()   获取仓库中的状态

store.dispatch(action)  分发到某个动作

store.subscribe(listener)  订阅仓库内状态更新

replaceReducer(nextReducer)  替换reducer

## 7 React-Redux

Ract-Redux 是 Redux的官方React绑定库，它能够使你的React组件从Redux store中读取数据，并且向store分发actions以更新数据。

学习网站：https://react-redux.js.org/

用 redux 库来创建 store ， 利用 react-redux 库来获取 store 中的数据或者更新数据。

react-redux 提供了两个常用的 api ，一个是： Provider，一个是：connect。 组件之间共享的数据是 Provider 这个顶层组件通过 props 传递下去的，**store必须作为参数放到Provider组件中去**。而 connect 则提供了组件获取 store 中数据或者更新数据的接口。

> 环境：create-react-app脚手架创建的项目、antd、redux、redux-react。

### 7.1 UI组件和容器组件

React-Redux 将所有组件分成两大类：UI 组件（负责 UI 的呈现）和容器组件（负责管理数据和逻辑）。

#### UI组件

1. 只负责 UI 的呈现，不带有任何业务逻辑
2. 没有状态（即不使用this.state这个变量）
3. 所有数据都由参数（this.props）提供
4. 不使用任何 Redux 的 API
5. 因为不含有状态，UI 组件又称为"纯组件"，即它跟纯函数一样，纯粹由参数决定它的值。

#### 容器组件

1. 负责管理数据和业务逻辑，不负责 UI 的呈现
2. 带有内部状态
3. 使用 Redux 的 API

#### UI 组件和容器组件的结合

1. 如果一个组件既有 UI 又有业务逻辑，那么将它拆分成两层结构：外面是一个容器组件，里面包了一个UI 组件。前者负责与外部的通信，将数据传给后者，由后者渲染出视图。
2. React-Redux 规定，所有的 UI 组件都由用户提供，容器组件则是由 React-Redux 自动生成。

### 7.2 安装

前提是已经安装了redux库

```shell
$ npm install react-redux --save
# 或
$ yarn add react-redux
```

### 7.3 connect函数及Provider

react-redux在7.1版本之前使用connect函数配合Provider来进行操作。以下介绍7.1版本之前的Provider及connect函数。

#### 1 API

#####  `<Provider>`组件

connect方法生成容器组件以后，需要让容器组件拿到state对象，才能生成 UI 组件的参数。一种解决方法是将state对象作为参数，传入容器组件。但是容器组件可能在很深的层级，一级级将state传下去就很麻烦。React-Redux 提供Provider组件，可以让容器组件拿到state。在根组件外面包了一层Provider，App的所有子组件都可以拿到state了。它的原理是React组件的context属性，store放在了上下文对象context上面。React-Redux自动生成的容器组件的代码，就类似下面这样，然后子组件就可以从context拿到store。

```jsx
// src/index.js
<Provider store={store}>
  <App />
</Provider>
```

##### connect()

钩子最初是在 v7.1.0 中添加的，在此之前使用connect来处理问题。

React-Redux中的connect()方法用于从 UI 组件生成容器组件，connect(mapStateToProps?, mapDispatchToProps?, mergeProps?, options?) 。之后就可以在该组件的props中获取到仓库中数据和dispatch方法。

```js
export default connect(mapStateToProps, mapDispatchToProps)(TodoRR);
```

###### mapStateToProps()

mapStateToProps 字面含义是把state映射到props中去，意思就是把Redux中的数据映射到React中的props中去。

1. mapStateToProps是一个函数。它的作用是建立一个从外部state对象到 UI 组件的props对象的映射关系。执行后返回一个对象，里面的每一个键值对就是一个映射。
2. mapStateToProps会订阅（绑定） Store，每当state更新的时候，就会自动执行，重新计算 UI 组件的参数，从而触发 UI 组件的重新渲染。
3. mapStateToProps的第一个参数总是`state对象`，还可以使用第二个参数，代表容器组件的props对象。使用ownProps作为参数后，如果容器组件的参数发生变化，也会引发 UI 组件重新渲染。
4. 如果connect方法省略mapStateToProps参数，那么UI 组件就不会订阅Store，就是说 Store 的更新不会引起 UI 组件的更新。

```js
// 映射仓库中的数据到props中
const mapStateToProps = (state, ownProps) => {
  return {
    inputValue: state.inputValue,
    test: 'hello',
    listData: state.listData
  }
}
```

###### mapDispatchToProps()

mapStateToProps 字面含义是把dispatch映射到props中去，意思就是把Redux中的修改数据的方法映射到React中的props中去。

1. mapDispatchToProps是connect函数的第二个参数，用来建立 UI 组件的参数到store.dispatch方法的映射。也就是说，它定义了用户的哪些操作应该当作 Action，传给 Store。它可以是一个函数，也可以是一个对象。
2. 如果mapDispatchToProps是一个函数，会得到dispatch和ownProps（容器组件的props对象）两个参数，应该返回一个对象，该对象的每个键值对都是一个映射，定义了 UI 组件的参数怎样发出 Action。
3. 如果mapDispatchToProps是一个对象，它的每个键名也是对应 UI 组件的同名参数，键值应该是一个函数，会被当作 Action creator ，返回的 Action 会由 Redux 自动发出。

```js
// 映射仓库中的dispatch到props中
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    inputChange: (e) => {
      // 获取input数据，更改store中的数据
      let action = {
        type: 'TO_CHANGE_INPUT',
        value: e.target.value
      };
      // 分发action
      dispatch(action);
      console.log('12132');
    },
    // 添加
    toAdd: () => {
      let action = {
        type: 'TO_ADD'
      };
      dispatch(action);
    },
    // 删除
    toDelete: (index) => {
      // console.log(index);
      let action = {
        type: 'TO_DELETE',
        index
      };
      dispatch(action);
    },
    // 完成
    toChangeStatus: (index) => {
      let action = {
        type: 'TO_CHANGE_STATUS',
        index
      };
      dispatch(action);
    },
  }
}
```

#### 2 使用

##### 注入仓库到组件

在项目index.js里，引入Provider，引入store，然后使用Provider组件。`<Provider>`是一个提供器，只要使用了这个组件，组件里边的其它所有子组件都可以使用store了。

```jsx
// src/index.js
import { Provider } from 'react-redux'
import store from './store'

// ....
<Provider store={store}>
  <App />
</Provider>
// ....
```

##### 组件使用store中的数据

在需要使用store数据的地方，引入连接器

```js
import {connect} from 'react-redux';  //引入连接器
```

创建映射关系，把原来的state映射成组件中的props属性

```js
const stateToProps = (state)=>{
  return {
    inputValue : state.inputValue
  }
}
```

导出组件

```js
export default connect(mapStateToProps)(TodoRR)
```

mapStateToProps，传入所有state，返回指定的state数据，最终放置到组件的props中。

```js
function mapStateToProps(state) {
	return { todos: state.todos }
}
```

##### 组件分发动作

mapDispatchToProps，传入dispatch，返回的对象中的方法会在组件的props中。

```js
const mapDispatchToProps = (dispatch) => {
  return {
    inputChange(e) {
      dispatch(changeInputAction(e.target.value));
    }
  }
}
// 导出组件
export default connect(mapStateToProps,mapDispatchToProps)(TodoRR)
```

connect的作用是把UI组件（无状态组件）和业务逻辑代码的分开，然后通过connect再连接到一起，让代码更加清晰和易于维护。这也是React-Redux最大的优点。

#### 3 备忘录案例

从创建reducer，使用时间解析函数，到创建仓库的步骤与之前redux的备忘录的例子保持一致。react-redux库的作用就是简化了组件获取仓库数据以及修改仓库数据的过程。

在src/store/reducer.js文件中：

```js
// src/store/reducer.js
import util from '../utils/util'
// 函数  reducer
const initState = {
  inputValue: '',
  listData: [{
    text: '备忘录1',
    time: '2019-09-09 09:09:09',
    status: '未完成'
  }, {
    text: '备忘录2',
    time: '2019-09-10 09:09:09',
    status: '已完成'
  }]
};
export default (state = initState, action) => {
  console.log('reducer');
  if (action.type === "TO_CHANGE_INPUT") {
    let obj = {
      ...state,
      inputValue: action.value
    }
    console.log(obj);
    return obj;
    /* return {
      ...state,
      inputValue: action.value
    }; */
  }
  if (action.type === 'TO_ADD') {
    // 修改仓库
    let obj = {
      text: state.inputValue,
      time: util.parseDate(),
      status: '未完成'
    };
    let { listData } = state;
    listData.push(obj);
    return {
      ...state,
      listData,
      inputValue: ''
    }
  }
  if (action.type === "TO_DELETE") {
    let { listData } = state;
    listData = [...listData];
    listData.splice(action.index, 1);
    return {
      ...state,
      listData
    }
  }
  if (action.type === "TO_CHANGE_STATUS") {
    let { listData } = state;
    listData = [...listData];
    listData[action.index].status = '已完成';
    return {
      ...state,
      listData
    }
  }
  return { ...state };

}
```

其中用到了处理时间的函数，在src/utils/util.js中：

```js
// src/utils/util.js
function parseDate() {
  let date = new Date();
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();
  let hours = date.getHours();
  let minutes = date.getMinutes();
  let seconds = date.getSeconds();
  return year + '-' + formatNum(month) + '-' + formatNum(day) + ' ' + formatNum(hours) + ':' + formatNum(minutes) + ':' + formatNum(seconds);
}
function formatNum(num) {
  return num > 10 ? num : ('0' + num);
}
export default {
  parseDate
}
```

reducer创建好了之后，再创建仓库对象，在src/store/index.js文件中：

```js
// src/store/index.js
// 仓库 store
import { createStore } from 'redux';
import reducer from './reducer';
// 将reducer与store绑定，创建store并返回
export default createStore(reducer);
```

**从以下开始发生变化**

注入仓库到根组件中，内部的子组件就可以使用仓库了。

```jsx
// src/index.js
import { Provider } from 'react-redux'
import store from './store'

// ....
<Provider store={store}>
  <App />
</Provider>
// ....
```

新建src/components/ToDoRR.js，内容如下，大体内容不变，有如下几点变化需注意：

1. 不用再在组件内来引入store了
2. 当前组件由函数纯UI组件经connect连接函数包装之后变为容器组件
3. 通过mapStateToProps和mapDispatchToProps将仓库内的状态和dispatch映射到了当前组件的props中
4. 在当前组件内会频繁的使用props来完成功能

```jsx
// src/components/ToDoRR.js
import React from 'react';
import { connect } from 'react-redux';
import { Button, Input, List } from 'antd';
let ToDoRR = (props) => {
  return (
    <div style={{ padding: 20 }}>
      <h2>备忘录{props.title}</h2>
      <div>
        <Input type="text" value={props.inputValue} onChange={props.inputChange} style={{ width: 200 }} />
        <Button type="primary" onClick={props.toAdd}>添加</Button>
      </div>
      <div style={{ marginTop: 10 }}>
        {/* 展示数组 */}
        <List size="small"
          bordered
          dataSource={props.listData}
          renderItem={(item, index) => (
            <List.Item>
              <List.Item.Meta
                title={<span style={{ color: item.status === '未完成' ? 'red' : 'green' }}>[{item.status}]{item.text}&nbsp;&nbsp;{item.time}</span>}
              />
              <div>
                {
                  item.status === '未完成' && <Button type="link" onClick={() => { props.toChangeStatus(index) }}>完成</Button>
                }
                <Button type="link" onClick={() => { props.toDelete(index) }}>删除</Button>
              </div>
            </List.Item>
          )}
        />
      </div>
    </div >
  );
}
// 映射仓库中的state数据到props中
const mapStateToProps = (state, ownProps) => {
  return {
    inputValue: state.inputValue,
    title: 'react-redux和redux结合使用',
    listData: state.listData
  }
}
// 映射仓库中的dispatch数据到props中
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    inputChange: (e) => {
      // 获取input数据，更改store中的数据
      let action = {
        type: 'TO_CHANGE_INPUT',
        value: e.target.value
      };
      // 分发action
      dispatch(action);
    },
    // 添加
    toAdd: () => {
      let action = {
        type: 'TO_ADD'
      };
      dispatch(action);
    },
    // 删除
    toDelete: (index) => {
      // console.log(index);
      let action = {
        type: 'TO_DELETE',
        index
      };
      dispatch(action);
    },
    // 完成
    toChangeStatus: (index) => {
      let action = {
        type: 'TO_CHANGE_STATUS',
        index
      };
      dispatch(action);
    },
  }
}
// 将UI组件包裹为容器组件
export default connect(mapStateToProps, mapDispatchToProps)(ToDoRR);
```

在App.js中引入并使用该组件

```jsx
// App.js
import ToDoRR from './components/ToDoRR'
// ....
export default function App() {
  return <div>
    <ToDoRR></ToDoRR>
  </div> 
}
// ....
```

结果

![image-20220718100147426](image/image-20220718100147426.png)



总结：react-redux库和redux库结合使用，redux库专注于仓库，react-redux库专注与组件与仓库的通信 。react-redux库重点：Provider组件和connect函数。

### 7.4 Hooks及Provider

react-redux在7.1版本之后使用hooks配合Provider来进行操作。以下介绍7.1版本之后的Provider及hooks。

#### 1 API

#####  `<Provider>`组件

Provider组件依然适用。

React-Redux 提供Provider组件，可以让容器组件拿到state。在根组件外面包了一层Provider，App的所有子组件都可以拿到state了。它的原理是React组件的context属性，store放在了上下文对象context上面。React-Redux自动生成的容器组件的代码，就类似下面这样，然后子组件就可以从context拿到store。

```jsx
// src/index.js
import { Provider } from 'react-redux'
import store from './store'

// ....
<Provider store={store}>
  <App />
</Provider>
// ....
```

##### useSelector()

允许使用选择器函数从 Redux 存储状态中提取数据。选择器函数应该是纯函数，因为它可能会在任意时间点多次执行。

```js
const result: any = useSelector(selector: Function, equalityFn?: Function)
```

selector在概念上大致等同于`mapStateToProps`参数。`connect`将使用整个 Redux 存储状态作为其唯一参数调用selector。每当函数组件渲染时，selector就会运行（除非它的引用自上次渲染组件以来没有更改，以便挂钩可以返回缓存的结果而无需重新运行Selector）。`useSelector()`还将订阅 Redux 存储，并在分派操作时运行您的Selector。

selector和mapState函数之间存在一些差异：

- selector可以返回任何值作为结果，而不仅仅是一个对象。selector的返回值将作为`useSelector()`钩子的返回值。
- 当一个动作被调度时，`useSelector()`会对之前的selector结果值和当前的结果值做一个参考比较。如果它们不同，组件将被强制重新渲染。如果它们相同，则组件不会重新渲染。
- selector函数不*接收*参数`ownProps`。
- `useSelector()`默认情况下使用严格`===`的引用相等检查，而不是浅相等

```jsx
import React from 'react'
import { useSelector } from 'react-redux'

export const CounterComponent = () => {
  const counter = useSelector((state) => state.counter)
  return <div>{counter}</div>
}
```

##### useDispatch()

`dispatch`这个钩子从 Redux 存储中返回对函数的引用。您可以根据需要使用它来调度操作。

```jsx
import React from 'react'
import { useDispatch } from 'react-redux'

export const CounterComponent = ({ value }) => {
  const dispatch = useDispatch()

  return (
    <div>
      <span>{value}</span>
      <button onClick={() => dispatch({ type: 'increment-counter' })}>
        Increment counter
      </button>
    </div>
  )
}
```

优化：避免由于回调引用更改而导致子组件不必要的渲染。

```jsx
import React, { useCallback } from 'react'
import { useDispatch } from 'react-redux'

export const CounterComponent = ({ value }) => {
  const dispatch = useDispatch()
  const incrementCounter = useCallback(
    () => dispatch({ type: 'increment-counter' }),
    [dispatch]
  )

  return (
    <div>
      <span>{value}</span>
      <MyIncrementButton onIncrement={incrementCounter} />
    </div>
  )
}

export const MyIncrementButton = React.memo(({ onIncrement }) => (
  <button onClick={onIncrement}>Increment counter</button>
))
```

##### useStore()

这个钩子返回对传入`<Provider>`组件的同一个 Redux 存储的引用。

```js
const store = useStore()
```

这个钩子可能不应该经常使用。首选`useSelector()`作为您的首选。但是，这对于需要访问存储的不太常见的场景（例如更换减速器）可能很有用。

```jsx
import React from 'react'
import { useStore } from 'react-redux'

export const CounterComponent = ({ value }) => {
  const store = useStore()

  // EXAMPLE ONLY! Do not do this in a real app.
  // The component will not automatically update if the store state changes
  return <div>{store.getState()}</div>
}
```

#### 2 备忘录案例

只修改组件内的使用，其他的内容不用动。

创建src/components/ToDoRR2.js，内容与ToDoRR.js大致相同，有以下内容不同：

1. 去除connect函数、mapState、mapDispatch映射
2. 引入useSelector、useDispatch之类的Hook
3. 不再通过props来获取数据和分发动作

```jsx
import React from 'react';
import { useSelector, useDispatch } from 'react-redux'
import { Button, Input, List } from 'antd';
let ToDoRR2 = () => {
  // 获取仓库中的数据
  let inputValue = useSelector((state) => state.inputValue);
  let listData = useSelector((state) => state.listData);
  // 获取dispatch函数
  const dispatch = useDispatch();
  return (
    <div style={{ padding: 20 }}>
      <h2>备忘录-react-redux hooks</h2>
      <div>
        {/* 分发动作 */}
        <Input type="text" value={inputValue} onChange={(e) => { dispatch({ type: 'TO_CHANGE_INPUT', value: e.target.value }) }} style={{ width: 200 }} />
        <Button type="primary" onClick={() => {
          dispatch({ type: 'TO_ADD' })
        }}>添加</Button>
      </div>
      <div style={{ marginTop: 10 }}>
        {/* 展示数组 */}
        <List size="small"
          bordered
          dataSource={listData}
          renderItem={(item, index) => (
            <List.Item>
              <List.Item.Meta
                title={<span style={{ color: item.status === '未完成' ? 'red' : 'green' }}>[{item.status}]{item.text}&nbsp;&nbsp;{item.time}</span>}
              />
              <div>
                {
                  item.status === '未完成' && <Button type="link" onClick={() => {
                    dispatch({
                      type: 'TO_CHANGE_STATUS', index
                    })
                  }}>完成</Button>
                }
                {/* 分发动作 */}
                <Button type="link" onClick={() => { dispatch({ type: 'TO_DELETE', index }) }}>删除</Button>
              </div>
            </List.Item>
          )}
        />
      </div>
    </div >
  );
}
export default ToDoRR2;
```

效果

![image-20220718113229772](image/image-20220718113229772.png)

## 8 中间件

redux中间件⽤于拓展redux功能。

> 环境：create-react-app脚手架创建的项目、redux、react-redux、axios、redux-thunk/redux-saga。

### 8.1 redux-thunk

redux中的reducer中都是同步操作，如果想要有异步操作，需要借助中间件，redux-thunk或者redux-saga。

redux-thunk是Redux 的Thunk中间件。它允许编写内部带有逻辑的函数，这些函数可以与 Redux 存储`dispatch`和`getState`方法进行交互。

学习资料：https://www.npmjs.com/package/redux-thunk、https://redux.js.org/usage/writing-logic-thunks

#### 安装

```shell
$ npm install redux-thunk --save
```

#### 配置

```js
// src/store/index.js
import {createStore,applyMiddleware} from "redux";
//引入redux-thunk
import thunk from "redux-thunk";
// 引入reducer
import reducer from "./reducer";
//使用react-thunk中间件，applyMiddleware使用中间件
export default createStore(reducer,applyMiddleware(thunk));
```

根据上方代码进行配置就可以使用redux-thunk了，如果想让谷歌浏览器的redux devtools有效，那么需要如下操作，需引入compose增强函数。

```js
import {createStore,applyMiddleware,compose} from "redux";
// ...
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : compose;
const enhancer = composeEnhancers(applyMiddleware(thunk))
export default createStore(reducer,enhancer)
```

对比之前没有使用中间件的redux devtools相关代码

```js
export default createStore(reducer, window.__REDUX_DEVTOOLS_EXTENSION__
  && window.__REDUX_DEVTOOLS_EXTENSION__());
```

#### 使用

既然要测试异步请求，那就先安装axios库。

```shell
$ npm install axios --save
```

创建src/store/asyncReducer.js文件，引入axios，准备编写异步action。

```js
// src/store/asyncReducer.js
import axios from 'axios'
// 初始状态
let initState = {
  myData: [],
};
// 同步动作生成器
let myactionCreator = (payload) => {
  return {
    type: 'SET_MY_DATA',
    payload
  }
}

// 异步动作
// redux-thunk的action
export const getMyData = () => {
  return (dispatch) => {
    axios.get('http://124.223.22.76:7001/count/countAll')
      .then((res) => {
        //同步action
        dispatch(myactionCreator(res.data.data));
      });
  }
}
// reducer
let asyncReducer = (state = initState, action) => {
  console.log('reducer', initState);
  if (action.type === 'SET_MY_DATA') {
    return {
      ...state,
      myData: action.payload
    }
  }
  return {
    ...state
  }
}
export default asyncReducer;
```

将该reducer注入到仓库中，注意将导出的store应用到根组件的Provider内。

```js
// src/store/index.js
// 仓库 store
import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import reducer from './reducer';
// 引入asyncReducer
import asyncReducer from './asyncReducer';
import thunk from "redux-thunk";
// 合并reducer
let totalReducer = combineReducers({
  reducer, asyncReducer
})

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : compose;
const enhancer = composeEnhancers(applyMiddleware(thunk))
// 生成store并导出
export default createStore(totalReducer, enhancer)
```

编写src/components/ThunkTest.js文件，内容如下：

```jsx
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getMyData } from '../store/asyncReducer'
let ThunkTest = () => {
  let myData = useSelector(state => state.asyncReducer.myData)
  let dispatch = useDispatch();
  return <div>
    <button onClick={() => { dispatch(getMyData()) }}>点击我执行异步action获取数据</button>
    <div>{JSON.stringify(myData)}</div>
  </div>
}
export default ThunkTest
```

在App.js中引入并使用该组件

```jsx
// App.js
import ThunkTest from './components/ThunkTest'
// ....
export default function App() {
  return <div>
    <ThunkTest></ThunkTest>
  </div> 
}
// ....
```

效果

![image-20220718153942972](image/image-20220718153942972.png)



无效操作：可以尝试直接在reducer中编写异步代码，然后在组件内直接分发SET_MY_DATA动作，会发现数据没有更改。也就是说在reducer中编写异步操作是无效的，这也是为什么我们要使用redux-thunk中间件的原因。使用了redux-thunk中间件后，可以编写action函数来执行异步逻辑，在组件内分发异步action。

```js
if (action.type === 'SET_MY_DATA') {
    axios.get('http://124.223.22.76:7001/count/countAll')
      .then((res) => {
        console.log(res); // 有数据，但是下方的代码更改不了state中数据，在reducer中编写异步是错误的，无效的
        return {
          ...state,
          myData: res.data.data
        }
    });
}
```

### 8.2 redux-saga

redux-saga是redux的中间件，用来处理异步操作。

学习网站：https://redux-saga.js.org/

使用generator函数在sagas文件中处理业务逻辑，有了redux-saga之后，除了reducer可以接收action并做业务逻辑处理，sagas也可以接收并做业务逻辑处理。

#### 安装

```shell
$ npm install redux-saga --save
```

#### 配置

将saga作为中间件注入到状态机中，其步骤有三：

1. 创建中间件redux-sage的中间件
2. 应用中间件
3. 执行中间件

```js
// src/store/index.js
// 引入中间件函数
import createSagaMiddleWare from 'redux-saga';
// 2.1创建中间件
const sagaMiddleWare=createSagaMiddleWare();
let store=createStore(
  combineReducers({todos,articles}),
  // 2.2 应用中间件
  applyMiddleware(sagaMiddleWare)
);
// 2.3执行中间件
sagaMiddleWare.run(mySagas); //mySagas为导入的sagas文件，对应异步操作
```

redux-saga把业务逻辑单独写一个文件，创建src/store/mySagas.js配置文件并引入到store中。

```js
// store/mySagas.js
function* mySagas() {}
export default mySaga;
```

将saga的配置文件引入到src/store/index.js中

```js
// src/store/index.js
import mySagas from './mySagas';
// 3 执行中间件
sagaMiddleware.run(mySagas);  //执行run方法，运行saga。注意运行的时机是在store创建好了之后，将中间件挂上去之后
```

#### 使用

创建src/store/asyncReducer2.js文件，内容如下

```js
// src/store/asyncReducer2.js
let initState = {
  myData: [],
};

let asyncReducer2 = (state = initState, action) => {
  if (action.type === 'SET_MY_DATA') {
    return {
      ...state,
      myData: action.payload
    }
  }
  return {
    ...state
  }
}
export default asyncReducer2;
```

新建src/store/mySagas.js文件

```js
// src/store/MySagas.js
import { takeEvery, put } from 'redux-saga/effects';
import axios from 'axios';
function* mySagas() {
  // 暴露异步函数  GET_MY_LIST是动作类型
  yield takeEvery('GET_MY_DATA', getMyData)
  yield takeEvery('GET_A', getA)
}
// 查询数据的异步操作
function* getMyData() {
  // 可以写业务逻辑
  const res = yield axios.get('http://124.223.22.76:7001/count/countAll');
  // 分发action，调用同步reducer 通过put提交数据给到reducer
  yield put({ type: 'SET_MY_DATA', payload: res.data.data });
}
function* getA() {
  // ....
}
export default mySagas;
```

使用中间件，如果要使用Redux DevTools调试插件，引入增强函数compose，src/store/index.js文件中的内容如下，注意将导出的store应用到根组件的Provider内。

```js
// src/store/index.js
import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import reducer from './reducer';
import asyncReducer2 from './asyncReducer2';
// 引入中间件函数
import createSagaMiddleware from 'redux-saga';
// 引入sagas文件
import mySagas from './mySagas';
// 增强函数
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : compose;
// 1 创建中间件
const sagaMiddleware = createSagaMiddleware();
// 2 应用中间件
const enhancer = composeEnhancers(applyMiddleware(sagaMiddleware))
// 合并reducer
let totalReducer = combineReducers({
  reducer, asyncReducer2
})
// 创建仓库
let store = createStore(totalReducer, enhancer);
// 3 执行中间件
sagaMiddleware.run(mySagas);
// 导出仓库
export default store;
```

组件挂载完毕之后，在组件中分发action，在sagas文件中处理业务逻辑。组件内主需要分发这个异步action，被saga监听到并执行对应的异步函数，与redux使用机制完全一致。新建src/components/SagaTest.js文件，内容如下：

```jsx
// src/components/SagaTest.js
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
let SagaTest = () => {
  let myData = useSelector(state => state.asyncReducer2.myData)
  let dispatch = useDispatch();
  return <div>
    {/* 分发action，此action被saga监听并执行 */}
    <button onClick={() => { dispatch({ type: 'GET_MY_DATA' }) }}>点击我执行saga异步获取数据</button>
    <div>{JSON.stringify(myData)}</div>
  </div>
}
export default SagaTest
```

在App.js中引入并使用该组件

```jsx
// App.js
import SagaTest from './components/SagaTest'
// ....
export default function App() {
  return <div>
    <SagaTest></SagaTest>
  </div> 
}
// ....
```

结果

![image-20220719093140361](image/image-20220719093140361.png)

## 9 Redux Toolkit

Redux Toolkit是redux的最终解决方案。

### 9.1 安装

（不推荐）创建好的react项目中，直接安装redux toolkit插件即可。

```shell
# Redux Toolkit 包含了 Redux 核心，以及我们认为对于构建 Redux 应用程序必不可少的其他关键软件包（例如 Redux Thunk 和 Reselect）。
$ npm install @reduxjs/toolkit
```

> redux包是Redux的核心库，react-redux包是React项目绑定Redux的包，@reduxjs/toolkit包内部包含了 Redux 核心，以及我们认为对于构建 Redux 应用程序必不可少的其他关键软件包（例如 Redux Thunk 和 Reselect）。

（推荐）开始一个新的 Create-React-App 项目，使用官方提供的 Redux 模板项目来创建。开箱即用，它已经配置了标准的 Redux 应用程序结构，使用 [Redux Toolkit](https://redux-toolkit.js.org/) 创建 Redux 存储和逻辑，以及 [React-Redux](https://react-redux.js.org/) 将 Redux 存储和 React 组件连接在一起。

redux-toolkit内置了thunk插件，不再需要单独安装，可以直接处理异步的action。

```shell
# 创建项目
$ npx create-react-app redux-app2 --template redux
$ cd redux-app2
$ npm start
# 启动之后，在http://localhost:3000端口上访问react脚手架的项目
```

项目依赖如下

![image-20220713103016836](image/image-20220713103016836.png)

效果：

![image-20220713095011361](image/image-20220713095011361.png)

项目目录

![image-20220713152707302](image/image-20220713152707302.png)

以下是构成此应用程序的关键文件：

- /src
  - `index.js`: the starting point for the app，入口文件
  - `App.js`: the top-level React component，顶级React组件
  - /app
    - `store.js`: creates the Redux store instance，创建redux仓库实例
  - /features
    - /counter
      - `Counter.js`: a React component that shows the UI for the counter feature，定时器UI界面
      - `counterSlice.js`: the Redux logic for the counter feature，定时器的redux逻辑

可以通过此项目了解一下redux是如何工作的。

### 9.2 创建 Redux Store

Redux store 是使用 Redux Toolkit 中的 `configureStore` 函数创建的。`configureStore` 要求我们传入一个 `reducer` 参数。

调用`configureStore` 时，我们可以传入一个对象中的所有不同的 reducer。 对象中的键名 key 将定义最终状态树中的键名 key。

我们有一个名为 `features/counter/counterSlice.js` 的文件，它为计数器逻辑导出了一个 reducer 函数。 我们可以在此处导入 `counterReducer` 函数，并在创建 store 时包含它。

当我们传入一个像 `{counter: counterReducer}` 这样的对象时，它表示我们希望在 Redux 状态对象中有一个 `state.counter` 部分，并且我们希望 `counterReducer` 函数负责决定是否以及如何在 dispatch action 时更新 `state.counter` 部分。

```jsx
// app/store.js
import { configureStore } from '@reduxjs/toolkit'
import counterReducer from '../features/counter/counterSlice'

export default configureStore({
  reducer: {
    // 属性名一般与state中的某个状态保持一致
    counter: counterReducer
  }
})
```

#### Redux 切片（Slice）

“切片”是应用中单个功能的 Redux reducer 逻辑和 action 的集合, 通常一起定义在一个文件中。该名称来自于将根 Redux 状态对象拆分为多个状态“切片”。

比如，在一个博客应用中，store 的配置如下：

```js
import { configureStore } from '@reduxjs/toolkit'
import usersReducer from '../features/users/usersSlice'
import postsReducer from '../features/posts/postsSlice'
import commentsReducer from '../features/comments/commentsSlice'

export default configureStore({
  reducer: {
    users: usersReducer,
    posts: postsReducer,
    comments: commentsReducer
  }
})
```

例子中，`state.users`，`state.posts`，和 `state.comments` 均是 Redux state 的一个切片“slice”。由于 `usersReducer` 负责更新 `state.users` 切片，我们将其称为“slice reducer”函数。

### 9.3 创建 Slice Reducer 和 Action

既然我们知道`counterReducer` 函数来自 `features/counter/counterSlice.js`，文件重点内容如下：

```js
import { createSlice,createAsyncThunk } from '@reduxjs/toolkit'
export const counterSlice = createSlice({
  name: 'counter',  // 命名空间，在调用action的时候会默认的设置为action的前缀
  initialState: {  // 初始state
    value: 0
  },
  // 这里的属性会自动的导出为actions，在组件中可以直接通过dispatch进行触发
  reducers: {
    increment: state => {
      // Redux Toolkit allows us to write "mutating" logic in reducers. It
      // doesn't actually mutate the state because it uses the immer library,
      // which detects changes to a "draft state" and produces a brand new
      // immutable state based off those changes
      // 内置了immutable，使用可变更新，并且不用将state返回
      state.value += 1
    },
    decrement: state => {
      state.value -= 1
    },
    incrementByAmount: (state, action) => {
      // payload载荷
      state.value += action.payload
    }
  }
})
// 导出actions
export const { increment, decrement, incrementByAmount } = counterSlice.actions
// 导出reducer，在创建store时使用到
export default counterSlice.reducer
```

在核心概念中，action 是带有 `type` 字段的普通对象，`type` 字段总是一个字符串，并且我们通常有 action creator 函数来创建和返回 action 对象。那么在切片文件中，哪里定义 了action 对象、类型字符串和 action creator 呢？

Redux Toolkit 有一个名为 `createSlice` 的函数，它负责生成 action 类型字符串、action creator 函数和 action 对象的工作。开发人员所要做的就是为这个切片定义一个名称，编写一个包含 reducer 函数的对象，它会自动生成相应的 action 代码。`name` 选项的字符串用作每个 action 类型的第一部分，每个 reducer 函数的键名用作第二部分。因此，`"counter"` 名称 + `"increment"` reducer 函数生成了一个 action 类型 `{type: "counter/increment"}`。这样就不用自己写action creator 函数来创建和返回 action 对象了。

除了 `name` 字段，`createSlice` 还需要我们为 reducer 传入初始状态值，以便在第一次调用时就有一个 `state`。在这种情况下，我们提供了一个对象，它有一个从 0 开始的 `value` 字段。

我们可以看到这里有三个 reducer 函数，它们对应于通过单击不同按钮 dispatch 的三种不同的 action 类型。

**`createSlice` 会自动生成与我们编写的 reducer 函数同名的 action creator**。我们可以通过调用其中一个来检查它并查看它返回的内容：

```js
console.log(counterSlice.actions.increment())
// {type: "counter/increment"}
console.log(counterSlice.actions.incrementByAmount(100))
// {type: "counter/incrementByAmount",payload:100}
```

它**还生成响应所有这些 action 类型的 slice reducer 函数**：

```js
const newState = counterSlice.reducer(
  { value: 10 },
  counterSlice.actions.increment()
)
console.log(newState)
// {value: 11}
```

虽然在reducer中看着好像是咱们写了可变更新来修改state中的数据，但是其实内部是不可变更新。是因为`createSlice` 内部使用了一个名为 [Immer](https://immerjs.github.io/immer/) 的库。 Immer 使用一种称为 “Proxy” 的特殊 JS 工具来包装您提供的数据，当你尝试 mutate 这些数据的时候，奇迹发生了，**Immer 会跟踪您尝试进行的所有更改，然后使用该更改列表返回一个安全的、不可变的更新值**，就好像您手动编写了所有不可变的更新逻辑一样。

> 注意：只能在 Redux Toolkit 的 `createSlice` 和 `createReducer` 中编写 “mutation” 逻辑，因为它们在内部使用 Immer！如果你在没有 Immer 的 reducer 中编写 mutation 逻辑，它将改变状态并导致错误！

在核心概念reducer中，是需要返回修改后的state对象的，但上方代码中并没有返回state对象，是因为Immer 知道我们已经对原来的 `state` 对象进行了更改，所以我们实际上不必在此处返回任何内容。

#### 总结

##### 创建slice

使用createSlice方法创建一个slice。每一个slice里面包含了reducer和actions，可以实现模块化的封装。所有的相关操作都独立在一个文件中完成。

##### 关键属性

name：命名空间，可以自动的把每一个action进行独立，解决了action的type出现同名的文件。在使用的时候默认会把使用`name/actionName`

initialState：state数据的初始值

reducers：定义的action。由于内置了immutable插件，可以直接使用赋值的方式进行数据的改变，不需要每一次都返回一个新的state数据。

### 9.4 用 Thunk 编写异步逻辑

到目前为止，我们应用程序中的所有逻辑都是同步的。首先 dispatch action，store 调用 reducer 来计算新状态，然后 dispatch 函数完成并结束。但是，JavaScript 语言有很多编写异步代码的方法，我们的应用程序通常具有异步逻辑，比如从 API 请求数据之类的事情。我们需要一个地方在我们的 Redux 应用程序中放置异步逻辑。

**thunk** 是一种特定类型的 Redux 函数，可以包含异步逻辑。Thunk 是使用两个函数编写的：

- 一个内部 thunk 函数，它以 `dispatch` 和 `getState` 作为参数
- 外部创建者函数，它创建并返回 thunk 函数

从 `counterSlice` 导出的函数就是一个 thunk action creator 的例子。

`createAsyncThunk` 方法可以创建一个异步的action，这个方法被执行的时候会有三个( pending(进行中) fulfilled(成功) rejected(失败))状态。可以监听异步动作状态的改变执行不同的操作，以下代码示例中使用到了extraReducers创建额外的action对数据获取的状态信息进行监听。

```js
import { createAsyncThunk } from '@reduxjs/toolkit';
import { fetchCount } from './counterAPI';
// The function below is called a thunk and allows us to perform async logic. It
// can be dispatched like a regular action: `dispatch(incrementAsync(10))`. This
// will call the thunk with the `dispatch` function as the first argument. Async
// code can then be executed and other actions can be dispatched. Thunks are
// typically used to make async requests.
// 内置了thunk插件，可以直接处理异步请求，异步动作
export const incrementAsync = createAsyncThunk(
  'counter/fetchCount',
  // { dispatch, getState }是ThunkAPI对象解构后的
  async (amount,{ dispatch, getState }) => {
    const response = await fetchCount(amount);
    // The value we return becomes the `fulfilled` action payload
    return response.data;
  }
);

export const counterSlice = createSlice({
  name:'counter',
  initialState:{
    value: 0,
  	status: 'idle',
  },
  reducers:{
    // 同步动作
  },
  // The `extraReducers` field lets the slice handle actions defined elsewhere,
  // including actions generated by createAsyncThunk or in other slices.
  // 可以额外的触发其他slice中的数据关联改变
  extraReducers: (builder) => {
    builder
      .addCase(incrementAsync.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(incrementAsync.fulfilled, (state, action) => {
        state.status = 'idle';
        state.value += action.payload;
      });
  },
}
```

我们可以像使用普通 Redux action creator 一样使用它们：

```js
store.dispatch(incrementAsync(5))
```

但是，使用 thunk 需要在创建时将 `redux-thunk` *middleware*（一种 Redux 插件）添加到 Redux store 中。幸运的是，Redux Toolkit 的 `configureStore` 函数已经自动为我们配置好了，所以我们可以继续在这里使用 thunk。

上方使用到的countAPI.js内的fetchCount函数如下：

```js
// countAPI.js
// A mock function to mimic making an async request for data
// 一个假的方法来模仿一个异步请求处理数据，此处模拟了一个异步请求
export function fetchCount(amount = 1) {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ data: amount }), 500)
  );
}
```

### 9.5 组件中的应用

#### 提取数据

使用 `useSelector` 提取数据，这个 hooks 让我们的组件从 Redux 的 store 状态树中提取它需要的任何数据。“selector” 函数，它以 `state` 作为参数并返回状态树的一部分。

`counterSlice.js` 在底部有这个 selector 函数：

```js
// features/counter/counterSlice.js
// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state: RootState) => state.counter.value)`
export const selectCount = (state) => state.counter.value;
```

如果我们可以访问 Redux 的 store，我们可以将当前计数器值检索为：

```js
const count = selectCount(store.getState())
console.log(count)
// 0
```

我们的组件不能直接与 Redux store 对话，因为组件文件中不能引入 store。但是，`useSelector` 负责为我们在幕后与 Redux store 对话。 如果我们传入一个 selector 函数，它会为我们调用 `someSelector(store.getState())`，并返回结果。

如下在Counter.js组件中获取仓库中的数据。

```js
import { useSelector } from 'react-redux'
// 获取仓库中的count状态的值
const count = useSelector(selectCount);
```

我们也不是*只能*使用已经导出的 selector。例如，我们可以编写一个选择器函数作为 `useSelector` 的内联参数：

```js
const countPlusTwo = useSelector(state => state.counter.value + 2)
```

每当一个 action 被 dispatch 并且 Redux store 被更新时，`useSelector` 将重新运行我们的选择器函数。如果选择器返回的值与上次不同，`useSelector` 将确保我们的组件使用新值重新渲染。

#### 分发动作(dispatch action)

使用 `useDispatch` Hook来 dispatch action。

类似地，我们知道如果我们可以访问 Redux store，我们可以使用 action creator 来 dispatch action，比如 `store.dispatch(increment())`。 由于我们无法访问 store 本身，因此我们需要某种方式来访问 `dispatch` 方法。

`useDispatch` hooks 为我们完成了这项工作，并从 Redux store 中为我们提供了实际的 `dispatch` 方法：

```jsx
import { useDispatch } from 'react-redux'
const dispatch = useDispatch()
// ....
// 在事件处理程序内分发动作
<button onClick={() => dispatch(increment())}>分发动作</button>
// ....
```

#### Providing the Store

我们已经看到我们的组件可以使用 `useSelector` 和 `useDispatch` 这两个 hooks 与 Redux 的 store 通信。奇怪的是，我们并没有导入 store，那么这些 hooks 怎么知道要与哪个 Redux store 对话呢？

在index.js文件中的内容如下：

```jsx
import React from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { store } from './app/store';
import App from './App';
import reportWebVitals from './reportWebVitals';
import './index.css';

const container = document.getElementById('root');
const root = createRoot(container);

root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

```

我们总是必须调用 `ReactDOM.render(<App />)` 来告诉 React 开始渲染我们的根 `<App>` 组件。 为了让像 `useSelector` 这样的 hooks 正常工作，我们需要使用一个名为 `<Provider>` 的组件在幕后传递 Redux store，以便他们可以访问它。

我们在这里引用来自 `app/store.js` 中创建的 store。然后，用 `<Provider>` 包裹整个 `<App>`，并传入 store：`<Provider store={store}>`。

现在，任何调用 `useSelector` 或 `useDispatch` 的 React 组件都可以访问 `<Provider>` 中的 store。

### 9.6 总结

- 我们可以使用 Redux Toolkit `configureStore` API 创建一个 Redux store
  - `configureStore` 接收 `reducer` 函数来作为命名参数
  - `configureStore` 自动使用默认值来配置 store
- 在 slice 文件中编写 Redux 逻辑
  - 一个 slice 包含一个特定功能或部分的 state 相关的 reducer 逻辑和 action
  - Redux Toolkit 的 `createSlice` API 为您提供的每个 reducer 函数生成 action creator 和 action 类型
- Redux reducer 必须遵循以下原则
  - 必须依赖 `state` 和 `action` 参数去计算出一个新 state
  - 必须通过拷贝旧 state 的方式去做 *不可变更新* (*immutable updates*)
  - 不能包含任何异步逻辑或其他副作用
  - Redux Toolkit 的 `createSlice` API 内部使用了 Immer 库才达到表面上直接修改（"mutating"）state 也实现不可变更新（*immutable updates*）的效果
- 一般使用 “thunks” 来开发特定的异步逻辑
  - Thunks 接收 `dispatch` 和 `getState` 作为参数
  - Redux Toolkit 内置并默认启用了 `redux-thunk` 中间件
- 使用 React-Redux 来做 React 组件和 Redux store 的通信
  - 在应用程序根组件包裹 `<Provider store={store}>` 使得所有组件都能访问到 store
  - 全局状态应该维护在 Redux store 内，局部状态应该维护在局部 React 组件内



# 第六章

学习目标：

+ dva
+ umi（乌米）

+ ant design pro

## 1 dva

学习网站：https://dvajs.com

## 2 umi

umi全称UmiJS，中文可发音为乌米，是一个可插拔的企业级前端框架。

学习网站：https://umijs.org/

### 包管理器

node 默认包含 npm，但也可以选择其他方案，

- [pnpm](https://pnpm.io/installation), umi 团队推荐
- [Yarn](https://yarnpkg.com/getting-started/install)

```shell
# 安装pnpm
$ npm install -g pnpm
# 查看pnpm的版本
$ pnpm -v
```

![image-20220719105758267](image/image-20220719105758267.png)

## 3 Ant Design Pro

Ant Design Pro 以 umi 作为脚手架，启动和开发与 umi 基本相同。

学习网站：https://pro.ant.design/zh-CN

**包管理器**

推荐使用 [tyarn](https://www.npmjs.com/package/tyarn) 来进行包管理，可以极大地减少 install 的时间和失败的概率，并且完全兼容 npm。

如果喜欢使用 npm 而不是 yarn，可以使用 [cnpm](https://www.npmjs.com/package/cnpm), 安装速度比 `tyarn` 更快，但是与 npm 不是完全兼容。

安装tyarn：`npm install yarn tyarn -g`

查看tyarn的版本：`tyarn -v`

### 3.1 开始使用

我们提供了 pro-cli 来快速的初始化脚手架。

```shell
# 使用 npm
$ npm i @ant-design/pro-cli -g
$ pro create my-proapp
```

选择 umi 的版本

```shell
? 🐂 使用 umi@4 还是 umi@3 ? (Use arrow keys)
  umi@4
❯ umi@3
```

如果选择了 umi@3，还可以选择 pro 的模板，pro 是基础模板，只提供了框架运行的基本内容，complete 包含所有区块，不太适合当基础模板来进行二次开发。

```shell
? 🚀 要全量的还是一个简单的脚手架? (Use arrow keys)
❯ simple
  complete
```

![image-20220714163932994](image/image-20220714163932994.png)

至此就执行项目模板下载的工作了，当项目模板下载完毕之后，安装依赖：

```shell
$ cd my-proapp
$ npm install  # 可能会出错，如果出错了就使用yarn安装依赖
# 安装依赖也可使用下方方式
# $ yarn
```

项目目录结构如下：

```csharp
├── mock                     # 本地模拟数据
├── public                   # 存放公共资源
├── src
│   ├── assets               # 本地静态资源
│   ├── common               # 导航信息和路由的配置
│   ├── components           # 通用组件的封装，如表格、表单
│   ├── e2e                  # 集成测试用例
│   ├── layouts              # 通用布局，整个网站的共用导航栏，页脚和主体部分
│   ├── models               # dva model
│   ├── routes               # 浏览器中所看到的页面
│   ├── services             # 后台接口服务
│   ├── utils                # 工具库
│   ├── g2.js                # 可视化图形配置
│   ├── theme.js             # 主题配置
│   ├── index.ejs            # HTML 入口模板，相当于index.html
│   ├── index.js             # 应用入口
│   ├── index.less           # 全局样式
│   └── router.js            # 路由入口
├── tests                    # 测试工具
├── README.md
└── package.json
```

Ant Design Pro 的架构图

![image-20220714164605221](image/image-20220714164605221.png)

dva：轻量级的应用框架，dva 首先是一个基于 [redux](https://github.com/reduxjs/redux) 和 [redux-saga](https://github.com/redux-saga/redux-saga) 的数据流方案，然后为了简化开发体验，dva 还额外内置了 [react-router](https://github.com/ReactTraining/react-router) 和 [fetch](https://github.com/github/fetch)，所以也可以理解为一个轻量级的应用框架。

Pro 的底座是 umi，umi 是一个 webpack 之上的整合工具。 umi 相比于 webpack 增加了运行时的能力，同时帮助我们配置了很多 webpack 的预设。也减少了 webpack 升级导致的问题。这也是我们能提供插件的原因。umi的4版本学习网站：https://umijs.org/docs/tutorials/getting-started。umi的3版本学习网站：https://v3.umijs.org/zh-CN

### 3.2 启动项目

在项目根目录下执行 `npm run start`, 即可启动项目。

![image-20220715092308348](image/image-20220715092308348.png)

在浏览器访问http://localhost:8000访问页面

![image-20220715092459739](image/image-20220715092459739.png)

![image-20220715092359716](image/image-20220715092359716.png)

在浏览器中访问http://localhost:8000/umi/plugin/openapi来访问开放API

![image-20220715093914631](image/image-20220715093914631.png)
